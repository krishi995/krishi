#!/usr/bin/python
# -*- coding: utf-8 -*-

from django.db import models
from django.urls import path
from django.template.defaultfilters import slugify
import os
import time
import zipfile
from django.core.files.uploadedfile import UploadedFile
from pathlib import Path
from django.core.files.storage import default_storage
import tempfile
import shutil 

def upload_callback(instance,filename):
	attribute = 'description'
	path = time.strftime("%Y%m%d%H%M%S",time.localtime())
	return '%s%s/%s/%s' % (path,slugify(getattr(instance,attribute)),"OldCode",filename)
		
		

	
def upload_callback1(instance,filename):
	attribute = 'description'
	path = time.strftime("%Y%m%d%H%M%S",time.localtime())
	return '%s%s/%s/%s' % (path,slugify(getattr(instance,attribute)),"NewCode",filename)



	
class Document(models.Model):
	description = models.CharField(max_length=255, blank=True)
	oldcode = models.FileField(default='0000000',
                               upload_to=upload_callback)
	newcode = models.FileField(default='000',
                               upload_to=upload_callback1)
	uploaded_at = models.DateTimeField(auto_now_add=True)
	


	
			
	