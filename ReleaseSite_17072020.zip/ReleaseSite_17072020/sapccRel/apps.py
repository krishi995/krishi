from django.apps import AppConfig


class SapccrelConfig(AppConfig):
    name = 'sapccRel'
