#!/usr/bin/python
# -*- coding: utf-8 -*-
from django.http import HttpResponse
from django.shortcuts import render
from subprocess import Popen, PIPE, STDOUT
from django.http import HttpResponse
import subprocess
import os
import glob
import array
import xml.etree.ElementTree as ET
from django.shortcuts import render
from .forms import DocumentForm
from django.conf import settings
from django.views.generic import ListView, CreateView, UpdateView
from django.urls import reverse_lazy
from .models import Document
import re
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import ElementTree
from django import template
from django.utils.safestring import mark_safe
from django.utils.html import conditional_escape
from django.template.defaultfilters import stringfilter
import tkinter as tk
from django.http import HttpResponseRedirect
import json
import cProfile
from django.urls import reverse
from django.contrib.auth.decorators import login_required
import time
import difflib
import zipfile
from collections import OrderedDict
from django.contrib import messages

from ReleaseSite.settings import BASE_DIR
from operator import itemgetter
import ast
from django.shortcuts import redirect
from django.shortcuts import render, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
import socket
import sys
import http.client

run = 'externalBin//codeCompare -fOldCode='
run1 = ' -fNewCode='
run2 = 'externalBin//ccHci -cc='
run3 = ' -l='
run4 = ' -f='
run5 = ' -c=externalBin//ccHciConfig.json'

	
@login_required
def model_form_upload(request):
	if request.method == 'POST':
		form = DocumentForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			messages.success(request, 'File upload successful')
			return redirect('model_form_upload.html')
	else:
		form = DocumentForm()
	return render(request, 'model_form_upload.html', {
        'form': form
    })

@login_required
def comparisonrun(request):
	
    return render(request, 'comparisonrun.html')

@login_required
def files(request):
    return render(request, 'files.html')
@login_required	
def comparison(request):
	if request.method == 'POST':
		a = request.POST['sel1']
	
		path3 = settings.MEDIA_ROOT
		path4 = path3 +'//' + a
		path1 = path3 +'//' + a + '//OldCode//'
		img_list1 = os.listdir(path1)
		file1 = str(img_list1[0])
		path2 = path3 + '//' + a + '//NewCode//'
		img_list2 = os.listdir(path2)
		file2 = str(img_list2[0])
		img_list3 = os.listdir(path4)
		files123 = [f for f in os.listdir(path4) if re.match(r'OutCompare_*', f)]
		print("files123:",files123)
		
		if "zip" in file1:
			path5 = 'runOutput' + '//' + a + '//OldCode//'
			location = path5 + file1
			print(location)
			with zipfile.ZipFile(location) as zf:
				zf.extractall(path5)
			os.remove(path5 + file1)
			
			
			path6 = 'runOutput' + '//' + a + '//NewCode//'	
			location1 = path6 + file2
			with zipfile.ZipFile(location1) as zf:
				zf.extractall(path6)
			os.remove(path6 + file2)
			
			def filepath(extractfile1):
				for root, directories, files in os.walk(extractfile1): 
					for filename in files:
						filepath = os.path.join(root, filename)
						return filepath 
			
			file6 = filepath(path5)
			print(file6)
			file7 = filepath(path6)
			print(file7)

			for files3 in img_list3:
				if files3 not in "OldCode":
					if files3 not in "NewCode":
						files4 = 'runOutput//' + a + '//' + files3 
						print(files4)
						os.remove(files4)
			myCmd = run + BASE_DIR +'//'+ file6+run1+ BASE_DIR + '//'+ file7 +' -outPath=' + path4 + '>' + path4 + '//CompareRunOutput.txt'
			os.system(myCmd)
			print(myCmd)
			files = [f for f in os.listdir(path4) if re.match(r'OutCompare_*', f)]
			file = str(files[0])
			file3 = file.replace(".txt",".json")
			file1 = 'runOutput//' + a + '//' + file
			i = 1
			Element = {}
			result = []
			with open(file1) as f:
				lines = f.readlines()
				for line in lines:
					if "allowanceInterface" not in line :
						if "counterNamesDictionary" not in line :
							if "{ }" not in line :
								
								r = line.split(":")
								
								t = r[1].split("]")
								x = t[0].strip("}")
								name = x.strip("{ ")
								
								
								s = t[1].strip(" ")
								valueType = s.strip("[")
								
								
								y = r[2].strip(" ")
								value = y.strip("]")
								
								
								c = r[3].strip("\n")
								if "####" in c:
									d = c.replace("####","")
									status = d.strip(" ")
									
								else:
									d = c.replace("****","")
									status = d.strip(" ")
								
								result.append({'name': name, 'valueType': valueType, 'value': value, 'status': status})
								i += 1
						
						y = []
						for x in sorted (result, key=itemgetter ('status'), reverse = True):
							y.append(x)
							
						
						Element = { "element": y }
						
						#print(result)
						
						
						result1 = json.dumps(Element,indent = 4).encode('utf-8')
						
						with open(path4 + "//"+ file3, "wb") as fout:
							fout.write(result1)
		
		elif files123 == []:
			path5 = 'runOutput' + '//' + a + '//OldCode//'
			location = path5 + file1
			print(location)
			
			
			
			path6 = 'runOutput' + '//' + a + '//NewCode//'	
			location1 = path6 + file2
			
			
			def filepath(extractfile1):
				for root, directories, files in os.walk(extractfile1): 
					for filename in files:
						filepath = os.path.join(root, filename)
						return filepath 
			
			file6 = filepath(path5)
			print(file6)
			file7 = filepath(path6)
			print(file7)

			for files3 in img_list3:
				if files3 not in "OldCode":
					if files3 not in "NewCode":
						files4 = 'runOutput//' + a + '//' + files3 
						print(files4)
						os.remove(files4)
						

			myCmd = run + BASE_DIR +'//'+ file6+run1+ BASE_DIR + '//'+ file7 +' -outPath=' + path4 + '>' + path4 + '//CompareRunOutput.txt'
			os.system(myCmd)
			print(myCmd)
			files = [f for f in os.listdir(path4) if re.match(r'OutCompare_*', f)]
			file = str(files[0])
			file3 = file.replace(".txt",".json")
			file1 = 'runOutput//' + a + '//' + file
			i = 1
			Element = {}
			result = []
			with open(file1) as f:
				lines = f.readlines()
				for line in lines:
					if "allowanceInterface" not in line :
						if "counterNamesDictionary" not in line :
							if "{ }" not in line :
								
								r = line.split(":")
								
								t = r[1].split("]")
								x = t[0].strip("}")
								name = x.strip("{ ")
								
								
								s = t[1].strip(" ")
								valueType = s.strip("[")
								
								
								y = r[2].strip(" ")
								value = y.strip("]")
								
								
								c = r[3].strip("\n")
								if "####" in c:
									d = c.replace("####","")
									status = d.strip(" ")
									
								else:
									d = c.replace("****","")
									status = d.strip(" ")
								
								result.append({'name': name, 'valueType': valueType, 'value': value, 'status': status})
								i += 1
						
						y = []
						for x in sorted (result, key=itemgetter ('status'), reverse = True):
							y.append(x)
							
						
						Element = { "element": y }
						
						#print(result)
						
						
						result1 = json.dumps(Element,indent = 4).encode('utf-8')
						
						with open(path4 + "//"+ file3, "wb") as fout:
							fout.write(result1)				
		files2 = [f for f in os.listdir(path4)]	
		for file in files2 :
			if ".json" in file:
				file1 = file
		path5 = path4 + "//"+ file1
		r = path5
		with open(r) as f:
			data = json.load(f)
		
		context = {"data" : data , "path" : a}
		
		return render(request, "comparisonrun.html", context, content_type="text/html")
		
		
	path = settings.MEDIA_ROOT
	img_list = os.listdir(path)
	img_list.sort(reverse = True)
	context = {'images' : img_list}
	
	
	return render(request, "comparisonrun.html", context)	
	
@login_required
def ComparisonOutput(request):
	if request.method == 'POST':
		a = request.POST['sel1']
		print(a)
		path5 = settings.MEDIA_ROOT
		path6 = path5 +'//' + a
		print(path6)
		file_list = os.listdir(path6)
		print(file_list)
		path = settings.MEDIA_ROOT
		img_list = os.listdir(path)
		img_list.sort(reverse = True)
		context = {'images' : img_list , 'files' : file_list , 'path' : a}	
		return render(request, "files.html", context)
	path = settings.MEDIA_ROOT
	img_list = os.listdir(path)
	img_list.sort(reverse = True)
	context = {'images' : img_list}
	return render(request, "files.html", context)
@login_required		
def changelist(request):
	BASE_DIR = settings.BASE_DIR
	path8 = os.path.join(BASE_DIR, 'externalBin//ccHciConfig.json')
	if request.method == 'POST':
		a = request.POST['sel1']
		b = request.POST['description']
		c = request.POST['sel2']
		path5 = settings.MEDIA_ROOT
		
		print("path8:",path8)
		path6 = path5 +'//' + c
		files = [f for f in os.listdir(path6) if re.match(r'CompareOutfinal*', f)]
		file = str(files[0])
		file1 = 'runOutput//' + c + '//' + file
		myCmd = run2 + a + run3 + b + run4 + file1 + run5 + '>' + path6 + '//ChangelistOutput.txt'
		print(myCmd)
		os.system(myCmd)
			
				
		path = settings.MEDIA_ROOT
		img_list = os.listdir(path)
		img_list.sort(reverse = True)
			
		r =  path8

		
		with open(r) as f:
			data = json.load(f)
			print("data",data)
				
		def file(data):
			for emp in data['sapcc']:
				yield emp['system']['id']
					
					
		systems = file(data)
	
		
		context = {'images' : img_list,'systems': systems}
		messages.success(request, b + ' Change list Created')
		return render(request, "home.html", context)
		
	r =  path8

		
	with open(r) as f:
		data = json.load(f)
		print("data",data)
			
	def file(data):
		for emp in data['sapcc']:
			yield emp['system']['id']
				
				
	systems = file(data)
		
	path = settings.MEDIA_ROOT
	img_list = os.listdir(path)
	img_list.sort(reverse = True)
	context = {'images' : img_list,'systems': systems }
	
	
	return render(request, "home.html", context)
@login_required	
def diff(request):
	if request.method == 'POST':
		a = request.POST['sel1']
		print(a)
			
			
		path5 = settings.MEDIA_ROOT		
		path6 = path5 +'//' + a
		files = [f for f in os.listdir(path6) if re.match(r'OutCompare_*', f)]
		file = str(files[0])
		file1 = 'runOutput//' + a + '//' + file
		file2 = 'runOutput//' + a + '//OldCode//' 
		file5 = 'runOutput//' + a + '//NewCode//'
		img_list1 = os.listdir(file2)
		file3 = str(img_list1[0])
		img_list2 = os.listdir(file5)
		file6 = str(img_list2[0])
		file4 = file2 + file3
		file7 = file5 + file6
		print(file4)
		apple = '####'
		str1 = apple.encode('utf-8')
		def apple_finder(file):
			for line in file:
				if str1 in line:
					yield line 
				
					
		source = open(file1,'rb')
		apples = []
		apples = apple_finder(source)
			
		path = settings.MEDIA_ROOT
		img_list = os.listdir(path)
		img_list.sort(reverse = True)
		
		context = {'images' : img_list,'apples': apples , 'old':file4 , 'new':file7}
		return render(request, 'modal.html', context)
	path = settings.MEDIA_ROOT
	img_list = os.listdir(path)
	img_list.sort(reverse = True)
	context = {'images' : img_list}
	return render(request, 'diff.html', context)

	
import cProfile
pr = cProfile.Profile()
pr.enable() 

@login_required
def modal(request):
	if request.method == 'POST':
		a = request.POST['sel2']
		print(a)
		def apple_finder2():
			if "chargePlan" in a: 
				
				newstr = a.split(' ')
				print("old:" , newstr[0])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargePlan}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[0].replace("'", "")
				print("file1 :", file )
				
					
				print("2:" ,string)
				tree = ET.parse(file)
				root = tree.getroot()
				for chargePlan in root.iter('chargePlan'):
					if chargePlan.get("id") == string:
						return ET.tostring(chargePlan)	
								
			if "allowancePlan" in a: 
				newstr = a.split(' ')
				print("old:" , newstr[0])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { allowancePlan}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[0].replace("'", "")
				print("file1 :", file )
				
					
				print("2:" ,string)
				tree = ET.parse(file)
				root = tree.getroot()
				for allowancePlan in root.iter('allowancePlan'):
					if allowancePlan.get("id") == string:
						return ET.tostring(allowancePlan)	
			if "allowanceLogic" in a: 
				newstr = a.split(' ')
				print("old:" , newstr[0])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { allowanceLogic}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[0].replace("'", "")
				print("file1 :", file )
				
					
				print("2:" ,string)
				tree = ET.parse(file)
				root = tree.getroot()
				for allowanceLogic in root.iter('allowanceLogic'):
					if allowanceLogic.get("id") == string:
						return ET.tostring(allowanceLogic)
			if "allowanceEventClass" in a: 
				newstr = a.split(' ')
				print("old:" , newstr[0])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { allowanceEventClass}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[0].replace("'", "")
				print("file1 :", file )
				
					
				print("2:" ,string)
				tree = ET.parse(file)
				root = tree.getroot()
				for allowanceEventClass in root.iter('allowanceEventClass'):
					if allowanceEventClass.get("id") == string:
						return ET.tostring(allowanceEventClass)	
			if "chargeComponent" in a: 
				newstr = a.split(' ')
				print("old:" , newstr[0])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargeComponent}] [Code : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[0].replace("'", "")
				print("file1 :", file )
				
					
				print("2:" ,string)
				tree = ET.parse(file)
				root = tree.getroot()
				for chargeComponent in root.iter('chargeComponent'):
					if chargeComponent.get("code") == string:
						return ET.tostring(chargeComponent)	
			if "pricingMacro" in a: 
				newstr = a.split(' ')
				print("old:" , newstr[0])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { pricingMacro}] [Code : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[0].replace("'", "")
				print("file1 :", file )
				
					
				print("2:" ,string)
				tree = ET.parse(file)
				root = tree.getroot()
				for pricingMacro in root.iter('pricingMacro'):
					if pricingMacro.get("code") == string:
						return ET.tostring(pricingMacro)	
						
			if "chargedItemClass" in a: 
				newstr = a.split(' ')
				print("old:" , newstr[0])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargedItemClass}] [Code : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[0].replace("'", "")
				print("file1 :", file )
				
					
				print("2:" ,string)
				tree = ET.parse(file)
				root = tree.getroot()
				for chargedItemClass in root.iter('chargedItemClass'):
					if chargedItemClass.get("code") == string:
						return ET.tostring(chargedItemClass)
			
			if "chargeComponent" in a: 
				newstr = a.split(' ')
				print("old:" , newstr[0])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargeComponent}] [Code : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[0].replace("'", "")
				print("file1 :", file )
				
					
				print("2:" ,string)
				tree = ET.parse(file)
				root = tree.getroot()
				for chargeComponent in root.iter('chargeComponent'):
					if chargeComponent.get("code") == string:
						return ET.tostring(chargeComponent)
				
		def apple_finder3():
			if "chargePlan" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargePlan}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for chargePlan in root.iter('chargePlan'):
					if chargePlan.get("id") == string:
						return ET.tostring(chargePlan)	
						
			if "allowancePlan" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { allowancePlan}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for allowancePlan in root.iter('allowancePlan'):
					if allowancePlan.get("id") == string:
						return ET.tostring(allowancePlan)
			if "allowanceLogic" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { allowanceLogic}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for allowanceLogic in root.iter('allowanceLogic'):
					if allowanceLogic.get("id") == string:
						return ET.tostring(allowanceLogic)
			if "chargeableItemClass" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargeableItemClass}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for chargeableItemClass in root.iter('chargeableItemClass'):
					if chargeableItemClass.get("id") == string:
						return ET.tostring(chargeableItemClass)	
			if "allowanceEventClass" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { allowanceEventClass}] [ID : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for allowanceEventClass in root.iter('allowanceEventClass'):
					if allowanceEventClass.get("id") == string:
						return ET.tostring(allowanceEventClass)	
			if "chargeComponent" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargeComponent}] [Code : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for chargeComponent in root.iter('chargeComponent'):
					if chargeComponent.get("code") == string:
						return ET.tostring(chargeComponent)	
						
			if "pricingMacro" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { pricingMacro}] [Code : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for pricingMacro in root.iter('pricingMacro'):
					if pricingMacro.get("code") == string:
						return ET.tostring(pricingMacro)
						
						
			if "chargedItemClass" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargedItemClass}] [Code : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for chargedItemClass in root.iter('chargedItemClass'):
					if chargedItemClass.get("code") == string:
						return ET.tostring(chargedItemClass)
			if "chargeComponent" in a: 
				newstr = a.split(' ')
				print("new:",newstr[1])
				newstr0 = a.replace(newstr[0], "")
				newstr1 = newstr0.replace(newstr[1], "")
				newstr2 = newstr1.replace("b'[Element : { chargeComponent}] [Code : ", "")
				newstr3 = newstr2.replace("] : #### Data NOT Matched ####//n'", "")
				string = newstr3.strip()
				file = newstr[1]
				print("file2 :", file )
				
				tree = ET.parse(file)
				root = tree.getroot()
				for chargeComponent in root.iter('chargeComponent'):
					if chargeComponent.get("code") == string:
						return ET.tostring(chargeComponent)
		

		code = apple_finder2()
		code1 = code.decode("utf-8")
		
		lines = code1.splitlines()
		
		
		
		
		
		
		
		
		code2 = apple_finder3()	
		code3 = code2.decode("utf-8")
		lines1 = code3.splitlines()
		
		#d = difflib.Differ()
		#diff3 = d.compare(lines,lines1)
		#diff4 = '\n'.join(diff3)
		#diff6 = d.compare(lines1,lines)
		#diff7 = '\n'.join(diff6)
		#diff5 = diff4.splitlines()
		#diff8 = diff7.splitlines()
		
		#diff9 = difflib.ndiff(lines, lines1)
		#diff10 = '\n'.join(diff9)
		#diff11 = diff10.splitlines()
		
		
		d = difflib.HtmlDiff()
		result = d.make_file(lines, lines1)
		
		print(result)
		
		
		
		
		
		
 
		empty = " "
		time.sleep(30)
		
		#context = {'code' : diff5 , 'code1': diff8 , 'diff' : diff,'diff1' : diff1,empty : 'empty'}
		#return render(request, 'code.html', context)
		return HttpResponse(result)

pr.print_stats(sort='time')

@login_required
def mango(request):
	if request.method == 'POST':
		#x = request.POST['sel3']
		if 'sel3' in request.POST:
			x = request.POST['sel3']
		
			print(x)
			out = x.split('*')
			x1 = out[0]
			x2 = out[1]
			str1 = x2.replace("\'", "\"")
			print(str1)
			path3 = settings.MEDIA_ROOT
			path1 = path3 +'//' + x1 + '//OldCode//'
			img_list1 = os.listdir(path1)
			file1 = str(img_list1[0])
			path6 = path3 +'//' + x1 + '//NewCode//'
			img_list2 = os.listdir(path6)
			file2 = str(img_list2[0])
			
			
			def filepath(extractfile1):
				for root, directories, files in os.walk(extractfile1): 
					for filename in files:
						filepath = os.path.join(root, filename)
						return filepath 
			
			file1 = filepath(path1)
			print(file1)
			file2 = filepath(path6)
			print(file2)
			obj = json.loads(str1);
			for key, value in obj.items():
				if key == "value" :
					d = value 
					
			#b = out[6]
			#c = b.replace("'","")
			#d = c.replace(",","")
			print(d)
			
					
			def apple_finder2():
				if "chargePlan" in out[1]: 
					
					
						
					print("2:" ,d)
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for chargePlan in root.iter('chargePlan'):
						if chargePlan.get("id") == d:
							return ET.tostring(chargePlan)	
									
				if "allowancePlan" in out[1]: 
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for allowancePlan in root.iter('allowancePlan'):
						if allowancePlan.get("id") == d:
							return ET.tostring(allowancePlan)

							
				if "allowanceLogic" in out[1]: 
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for allowanceLogic in root.iter('allowanceLogic'):
						if allowanceLogic.get("id") == d:
							return ET.tostring(allowanceLogic)
							
				if "allowanceEventClass" in out[1]: 
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for allowanceEventClass in root.iter('allowanceEventClass'):
						if allowanceEventClass.get("id") == d:
							return ET.tostring(allowanceEventClass)	
							
							
				if "chargeComponent" in out[1]: 
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for chargeComponent in root.iter('chargeComponent'):
						if chargeComponent.get("code") == d:
							return ET.tostring(chargeComponent)	
							
				if "pricingMacro" in out[1]: 
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for pricingMacro in root.iter('pricingMacro'):
						if pricingMacro.get("code") == d:
							return ET.tostring(pricingMacro)	
							
				if "chargedItemClass" in out[1]: 
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for chargedItemClass in root.iter('chargedItemClass'):
						if chargedItemClass.get("code") == d:
							return ET.tostring(chargedItemClass)
				
				if "chargeComponent" in out[1]: 
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for chargeComponent in root.iter('chargeComponent'):
						if chargeComponent.get("code") == d:
							return ET.tostring(chargeComponent)

				if "chargeableItemClass" in out[1]: 
					file = file1
					tree = ET.parse(file)
					root = tree.getroot()
					for chargeableItemClass in root.iter('chargeableItemClass'):
						if chargeableItemClass.get("id") == d:
							return ET.tostring(chargeableItemClass)

			def apple_finder3():
				if "chargePlan" in out[1]: 
					
					
						
					print("2:" ,d)
					file = file2
					tree = ET.parse(file)
					root = tree.getroot()
					for chargePlan in root.iter('chargePlan'):
						if chargePlan.get("id") == d:
							return ET.tostring(chargePlan)		
							
				if "allowancePlan" in out[1]: 
					file = file2
					tree = ET.parse(file)
					root = tree.getroot()
					for allowancePlan in root.iter('allowancePlan'):
						if allowancePlan.get("id") == d:
							return ET.tostring(allowancePlan)
							
				if "allowanceLogic" in out[1]: 
					file = file2
					
					tree = ET.parse(file)
					root = tree.getroot()
					for allowanceLogic in root.iter('allowanceLogic'):
						if allowanceLogic.get("id") == d:
							return ET.tostring(allowanceLogic)
							
				if "chargeableItemClass" in out[1]: 
					file = file2
					
					tree = ET.parse(file)
					root = tree.getroot()
					for chargeableItemClass in root.iter('chargeableItemClass'):
						if chargeableItemClass.get("id") == d:
							return ET.tostring(chargeableItemClass)	
							
							
				if "allowanceEventClass" in out[1]: 
					file = file2
					tree = ET.parse(file)
					root = tree.getroot()
					for allowanceEventClass in root.iter('allowanceEventClass'):
						if allowanceEventClass.get("id") == d:
							return ET.tostring(allowanceEventClass)	
							
				if "chargeComponent" in out[1]: 
					file = file2
					tree = ET.parse(file)
					root = tree.getroot()
					for chargeComponent in root.iter('chargeComponent'):
						if chargeComponent.get("code") == d:
							return ET.tostring(chargeComponent)	
							
				if "pricingMacro" in out[1]: 
					file = file2
					tree = ET.parse(file)
					root = tree.getroot()
					for pricingMacro in root.iter('pricingMacro'):
						if pricingMacro.get("code") == d:
							return ET.tostring(pricingMacro)
							
							
				if "chargedItemClass" in out[1]: 
					file = file2
					
					tree = ET.parse(file)
					root = tree.getroot()
					for chargedItemClass in root.iter('chargedItemClass'):
						if chargedItemClass.get("code") == d:
							return ET.tostring(chargedItemClass)
							
				if "chargeComponent" in out[1]: 
					file = file2
					
					tree = ET.parse(file)
					root = tree.getroot()
					for chargeComponent in root.iter('chargeComponent'):
						if chargeComponent.get("code") == d:
							return ET.tostring(chargeComponent)
				
				if "chargeableItemClass" in out[1]: 
					file = file2
					tree = ET.parse(file)
					root = tree.getroot()
					for chargeableItemClass in root.iter('chargeableItemClass'):
						if chargeableItemClass.get("id") == d:
							return ET.tostring(chargeableItemClass)


			code = apple_finder2()
			code1 = code.decode("utf-8")
			
			lines = code1.splitlines()
			
			
			
			
			
			
			
			
			code2 = apple_finder3()	
			code3 = code2.decode("utf-8")
			lines1 = code3.splitlines()
			
			#d = difflib.Differ()
			#diff3 = d.compare(lines,lines1)
			#diff4 = '\n'.join(diff3)
			#diff6 = d.compare(lines1,lines)
			#diff7 = '\n'.join(diff6)
			#diff5 = diff4.splitlines()
			#diff8 = diff7.splitlines()
			
			#diff9 = difflib.ndiff(lines, lines1)
			#diff10 = '\n'.join(diff9)
			#diff11 = diff10.splitlines()
			
			
			d = difflib.HtmlDiff()
			result = d.make_file(lines, lines1)
			
			
			
			
			
			
	 
			empty = " "
			time.sleep(30)
			
			#context = {'code' : diff5 , 'code1': diff8 , 'diff' : diff,'diff1' : diff1,empty : 'empty'}
			#return render(request, 'code.html', context)
			#context = {"message" : result}
			#return render(request, 'alert.html',context )
			return HttpResponse(result)
			#return render(None, 'alert.html', context)

			#return render(request, 'comparisonrun.html')

		else:
			x = request.POST.getlist('checks')
			print("x:",x)
			y = x[0].split('*')
			path = y[0]
			words = [w.replace(path + "*", '') for w in x]
			str1 = ''.join(words)
			str2 = str1.replace("'","\"")
			x1= ast.literal_eval(str1)
			print("x1:",type(x1))
		
			path3 = settings.MEDIA_ROOT
			path1 = path3 +'//' + path
			files = [f for f in os.listdir(path1) if re.match(r'OutCompare_*', f)]
			for file in files:
				if '.txt' in file:
					fout = str(file)
			
			file = open(path1 + "//CompareOutfinal.txt", "w+") 
			with open(path1 + "//" + fout ,"r") as fout1:
				for line in fout1:
					for k in x1:
						if line.find(k['name']) and line.find(k['value']+"]") != -1:
						#if k['name'] and k['value']in line:
							file.write(line)
					
				
				
			
			
			return redirect('/home/')