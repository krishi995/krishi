"""ReleaseSite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from django.conf.urls import include, url
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from sapccRel.views import *
from sapccRel.views import model_form_upload
from sapccRel.views import comparisonrun
from sapccRel.views import files
from sapccRel import views
from sapccRel.views import ComparisonOutput
from sapccRel.views import changelist
from sapccRel.views import diff

from sapccRel.views import modal
from sapccRel.views import mango
from django.contrib import admin
from django.contrib.auth import views as auth_views
from dappx import views

urlpatterns = [
    path('admin/', admin.site.urls),
	url(r'comparisonrun', comparison, name='comparisonrun'),
	url(r'diff', diff, name='diff'),
	url(r'modal', modal, name='modal'),
	url(r'files', ComparisonOutput, name='comparisonrun'),
	url(r'model_form_upload', model_form_upload, name='model_form_upload'),
	url(r'comparisonrun', comparison, name='comparison'),
	url(r'ComparisonOutput', ComparisonOutput, name='ComparisonOutput'),
	url(r'home', changelist, name='changelist'),
    url(r'^$',views.index,name='index'),
    url(r'^special/',views.special,name='special'),
    url(r'^dappx/',include('dappx.urls')),
    url(r'^logout/$', views.user_logout, name='logout'),
	url(r'mango', mango, name='mango'),
	
]
if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
							  

