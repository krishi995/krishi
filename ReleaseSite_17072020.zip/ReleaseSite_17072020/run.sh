/home/mzadmin/Rajesh/anaconda3/bin/python manage.py runserver 10.144.97.190:8005
