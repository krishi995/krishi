function arrayMin(arr) {
	var len = arr.length, min = Infinity;
	while (len--) {
		if (arr[len] < min) {
			min = arr[len];
		}
    }
	return min;
}

function greaterValue(value1,value2){
	if(value1 > value2) {
		return value1;
	}else{
		return value2;
	}
}

function minValue(value1,value2){
	if(value1 > value2) {
		return value2;
	}else{
		return value1;
	}
}

function arrayMax(arr) {
	var len = arr.length, max = -Infinity;
	while (len--) {
		if (arr[len] > max) {
			max = arr[len];
		}
	}
	return max;
};
 
// Static Array to show color Values
arrayColors= ["fill:#006837","fill:#753c19","fill:#49a5af","fill:#D9E021","fill:#F15A24","fill:#2253a3","fill:#721fa3","fill:#a38325", "fill:##a22581"] 
var viewSize = 400;
var fontBelowSize = 100; // Need to change
var recWidth = 40;
var spacingBetween=60;
var recHeight=40;
var fontTopSize = 20;
  
function drawBarChart(arrayName,arrayValue, svgId){
	var colElement, rectOnClick;
	if(svgId == "1"){
		$('#svgChart').empty();
		colElement = document.getElementById("svgChart");
		rectOnClick = "rectOnClick1";
	}else{
		$('#svgChartBit').empty();
		colElement = document.getElementById("svgChartBit");
		rectOnClick = "rectOnClick2";
	}
	var maxValue = arrayMax(arrayValue);
	var numStatus = arrayName.length;
	var scalingFactor=maxValue/viewSize;

	var maxViewBoxWidth = (arrayName.length-1)*spacingBetween + recWidth;
	var viewBoxHeight = viewSize+fontBelowSize+fontTopSize
	var svgElement = document.createElementNS("http://www.w3.org/2000/svg", 'svg');
	svgElement.setAttribute("viewbox","0 0 "+ maxViewBoxWidth + " "  + viewBoxHeight );
	svgElement.setAttribute("width","100%");
	svgElement.setAttribute("height",viewBoxHeight+fontTopSize);
	svgElement.setAttribute("preserveAspectRatio", "xMinYMin meet");

	for (var i=0; i< numStatus;i++)	{

		var txtElementTop=document.createElementNS("http://www.w3.org/2000/svg", 'text');
		txtElementTop.setAttribute("x",i*spacingBetween+ recWidth/2);
		txtElementTop.setAttribute("y",(maxValue-arrayValue[i])/scalingFactor + fontTopSize  )
		txtElementTop.setAttribute('fill', '#000');
		txtElementTop.textContent = arrayValue[i];
		txtElementTop.setAttribute("font-size","0.85em");
		
		var txtElementBelow = document.createElementNS("http://www.w3.org/2000/svg", 'text');
		txtElementBelow.setAttribute("x",i*spacingBetween+ recWidth/2); // recWidth/2 to centre it
		
		txtElementBelow.setAttribute('y', "510");  //Need to change
		txtElementBelow.setAttribute('fill', '#000');
		txtElementBelow.textContent = arrayName[i];
		var cxValue = txtElementBelow.getAttribute("x");  // recWidth/2 to centre it
		var cyValue = txtElementBelow.getAttribute("y");
		txtElementBelow.setAttribute("font-size","0.85em");
		txtElementBelow.setAttribute("transform","rotate(-90," + cxValue + "," + cyValue + ")")
		txtElementBelow.setAttribute("class",rectOnClick);
		txtElementBelow.setAttribute("id",arrayName[i]);
		
		
		var rectElement = document.createElementNS("http://www.w3.org/2000/svg", 'rect');
		rectElement.setAttribute("x",i*spacingBetween );
		rectElement.setAttribute("y",fontTopSize+(maxValue-arrayValue[i])/scalingFactor);
		rectElement.setAttribute("width",recWidth);
		rectElement.setAttribute("height",arrayValue[i]/scalingFactor);
		rectElement.style=arrayColors[i];
		rectElement.setAttribute("class",rectOnClick);
		rectElement.setAttribute("id",arrayName[i]);
		
		svgElement.appendChild(rectElement);
		svgElement.appendChild(txtElementBelow);
		svgElement.appendChild(txtElementTop);
	}
	colElement.appendChild(svgElement); 
};
