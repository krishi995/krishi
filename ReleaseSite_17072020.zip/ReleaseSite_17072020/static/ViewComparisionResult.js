var FailedCases = [];
var RANGE;
var NoRunCases = [];
function createXmlHttp() {
	var xhr;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xhr=new XMLHttpRequest();
	} else {// code for IE6, IE5
		xhr=new ActiveXObject('Microsoft.XMLHTTP');
	}
	return xhr;
}
//var itemData;
var COMPAREID, RUNID, TESTCASEID, RUNNORUNENV;

function loadViewComparisionPage() {
	//alert("yo");
	var xhr = createXmlHttp();
	xhr.onreadystatechange=function() {
		if (xhr.readyState==4 && xhr.status==200) {
			var testScenario = JSON.parse(xhr.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			//alert("hi");
			addRunId(mainPanel, testScenario.content);
			//itemData = testScenario.content;
		}
	}
	
	xhr.open('GET', 'loadComparisionResult.html?', true);
	xhr.send();
}

function addRunId(panel, item){
	//alert(item);
	if(item.length==0){
		alert("No Comparision Data Found.");
	}
	for (var i = 0; i < item.length; i++) {
		opt = document.createElement("option");
		opt.value = item[i].compareid + ":" + item[i].runid1 + ":" + item[i].runid2;
		//RUNID1 = item[i].runid1;
		//RUNID2 = item[i].runid2;
		//alert(opt.value);
		opt.text = item[i].compareid + " :- " + item[i].runid1 + "|" + item[i].description1 + " VS " + item[i].runid2 + "|" + item[i].description2 + " --> " + item[i].status1;
		document.getElementById('baseLine').appendChild(opt);
		
		
		var li = document.createElement("LI");
		li.id = opt.value;
		li.className = 'liOnClick';
		//li.onclick = onchange= function() {report1(li.id)};
		var elLink = document.createElement("A");
		var t = document.createTextNode(opt.text);
		elLink.setAttribute("href", "#");
		elLink.appendChild(t);
		li.appendChild(elLink);
		document.getElementById("myUL").appendChild(li);
		
	}
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
	
	var BitComparisonSummary = document.getElementById('BitComparisonSummary');
	BitComparisonSummary.style.display = 'none';
		
	var FailedTestCaseBit = document.getElementById('FailedTestCaseBit');
	FailedTestCaseBit.style.display = 'none';
	
	var FailedTestCaseResponse = document.getElementById('FailedTestCaseResponse');
	FailedTestCaseResponse.style.display = 'none';
	
	var myBtnBack = document.getElementById('myBtnBack');
	myBtnBack.style.display = 'none';
}

$(document).on('click', '.liOnClick', function(){
	document.getElementById("myInput").value = this.id;
	document.getElementById("baseLine").value = this.id;
	report(this.id);
});

function report(id){
	var BitComparisonSummary = document.getElementById('BitComparisonSummary');
	BitComparisonSummary.style.display = 'none';
	
	var BitComparisonSummary = document.getElementById('BitComparisonSummary');
	BitComparisonSummary.style.display = 'none';
		
	var FailedTestCaseBit = document.getElementById('FailedTestCaseBit');
	FailedTestCaseBit.style.display = 'none';
	
	var myBtnBack = document.getElementById('myBtnBack');
	myBtnBack.style.display = 'none';
	
	//alert(id);
	$('#tbody').empty();
	$('#svgChartBit').empty();
	
	document.getElementById("myInput").value = id;
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
	var list = id.split(":");
	COMPAREID=list[0];
	RUNID = list[1] + ":" + list[2];
	var request = new XMLHttpRequest();
	request.open("POST", 'CompareId='+COMPAREID, true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send();
	//alert('CompareId='+COMPAREID);
	//alert("Test Cases Run Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState==4 && request.status==200) {
			//alert("response recieved");
			//alert("response recieved: " + request.responseText);
			var testScenario = JSON.parse(request.responseText);
			console.log("Response RCVD");
			loadCompareData(testScenario.compareSummary);
			if(testScenario.bitCompareSummary != null && testScenario.bitCompareSummary != ""){
				//alert(testScenario.bitCompareSummary);
				loadCompareBitData(testScenario.bitCompareSummary);
			}
			//alert("Mismatch Row Count - "+testScenario.mismatchRowCount);
			populateMismatchDropdown(testScenario.mismatchRowCount);
		}
	}
}

function loadCompareBitData(itemData){
	var BitComparisonSummary = document.getElementById('BitComparisonSummary');
	BitComparisonSummary.style.display = 'block';
			
	$('#tblBitSummary').empty();
	$('#tbodyFailedBit').empty();
	$('#svgChartBit').empty();
	
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
	
	var countPass = 0, countFail = 0, countCurr = 0, countPrev = 0, countBoth = 0;
		
	var lgth = itemData.length;
			
	for(var j=0;j<lgth;j++){
		
		var tr = document.createElement('tr');
		tr.value = itemData[j].status;
		tr.id = "bit_" + itemData[j].testCaseId;
		
		var td1 = document.createElement('td');
		var td2 = document.createElement('td');
		var td3 = document.createElement('td');
		//var td4 =  document.createElement("input");
		//td4.type = "button";
		//td4.name = "Hello";
		//td4.value = "Random Value";		

		var text1 = document.createTextNode(itemData[j].testCaseId);
		var text2 = document.createTextNode(itemData[j].description);
		var text3 = document.createTextNode(itemData[j].status);
		
		td1.appendChild(text1);
		td2.appendChild(text2);
		td3.appendChild(text3);
		
		tr.appendChild(td1);
		tr.appendChild(td2);
		tr.appendChild(td3);
		//tr.appendChild(td4);
		if (itemData[j].status == 'Failed'){			
			tr.className = 'rowFailOnClickBit';			
			countFail = countFail + 1;
			tr.name = itemData[j].testCaseId;
		}else if (itemData[j].status == 'Passed'){
			countPass = countPass + 1;
		}else if (itemData[j].status == 'No Current Run'){
			countCurr = countCurr + 1;
		}else if (itemData[j].status == 'No Previous Run'){
			countPrev = countPrev + 1;
		}else if(itemData[j].status == 'Not Found For Both Run'){
			countBoth = countBoth + 1;
		}
		document.getElementById('tblBitSummary').appendChild(tr);
	}
	
	var arrayName = [];
	var arrayValue = [];
	
	if(countPass > 0){
		arrayName.push("Passed");
		arrayValue.push(countPass);
	}
	if(countFail > 0){
		arrayName.push("Failed");
		arrayValue.push(countFail);
		ComparisonFailedRun.style.display = 'block';
		//ComparisonMismatchExport.style.display = 'block';
		CmpMismatch.style.display = 'block';
	}
	if(countCurr > 0){
		ComparisonNoRun.style.display = 'block';
		arrayName.push("No Current Run");
		arrayValue.push(countCurr);
	}
	if(countPrev > 0){
		ComparisonNoRun.style.display = 'block';
		arrayName.push("No Previous Run");
		arrayValue.push(countPrev);
	}
	if(countBoth > 0){
		arrayName.push("Both Run No Bit");
		arrayValue.push(countBoth);
	}
	drawBarChart(arrayName,arrayValue,2);
}

var OFFSETTOP;

$(document).on('click', '.rowFailOnClickBit', function(){
	var comm1 = document.getElementById('comment1');
	var comm2 = document.getElementById('comment2');
	$('#comm1').empty();
	$('#comm2').empty();
	
	var FailedTestCaseBit = document.getElementById('FailedTestCaseBit');
	FailedTestCaseBit.style.display = 'block';
	
	var myBtnBack = document.getElementById('myBtnBack');
	myBtnBack.style.display = 'block';
	
	var FailedTestCaseResponse = document.getElementById('FailedTestCaseResponse');
	FailedTestCaseResponse.style.display = 'none';
	
	var elmnt = document.getElementById(this.id);
	//alert("elmnt of bit"+elmnt ); 
	OFFSETTOP = position(elmnt);
	//alert(OFFSETTOP);
	
	
	var str = COMPAREID + ":" + this.name;
	//alert(str);
	var request = new XMLHttpRequest();
	request.open("POST", 'CompareTestCaseBitData', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert('str='+str);
	TESTCASEID = this.name;
	
	request.onreadystatechange = function() {
		if (request.readyState==4 && request.status==200) {
			if(JSON.parse(request.responseText) == null){
				alert("No Data Found");
			}else{
				//alert(request.responseText);
				var testScenario = JSON.parse(request.responseText);
				loadCompareTestCaseBitData(testScenario.compareReportBit);
			}
		}
	}
});

var ID, KEY;

function loadCompareTestCaseBitData(itemData){
	$('#tbodyFailedBit').empty();
	
	
	//alert("Hi");
	var lgth = itemData.length;
	//alert(lgth);
	//alert(itemData);
	
	for(var j=0;j<lgth;j++){
		var tr = document.createElement('tr');
		tr.name = itemData[j].testCaseId;
		tr.value = itemData[j].status;
		tr.style.border = '1px solid black';
		tr.id = itemData[j].testCaseId + ":" + itemData[j].bitType + ":" + itemData[j].recordId + ":" + itemData[j].status;
		ID = tr.id;
		
		var td1 = document.createElement('td');
		var td2 = document.createElement('td');
		var td3 = document.createElement('td');
		var td4 = document.createElement('td');
		var td5 = document.createElement('td');
		var td6 = document.createElement('td');
		var td7 = document.createElement('td');
		
		var text1 = document.createTextNode(itemData[j].testCaseId);
		var text2 = document.createTextNode(itemData[j].bitType);
		var text3 = document.createTextNode(itemData[j].recordId);
		
		var key = itemData[j].key;
		KEY = key;
		if( key == null)
			key = "NA";
		var prevBitCount = itemData[j].prevBitCount;
		if( prevBitCount == null)
			prevBitCount = "NA";
		var currBitCount = itemData[j].currBitCount;
		if( currBitCount == null)
			currBitCount = "NA";
		
		var text4 = document.createTextNode(key);
		var text5 = document.createTextNode(prevBitCount);
		var text6 = document.createTextNode(currBitCount);
		var text7 = document.createTextNode(itemData[j].status);
		
		if(itemData[j].status != 'Match' && itemData[j].status != 'Count MisMatch' && itemData[j].status != 'File Not Found' && itemData[j].status != 'Count Match'){
			tr.className = 'rowOnClickBit';
			tr.style.backgroundColor = '#F08080';
		}else if (itemData[j].status == 'Count MisMatch' || itemData[j].status == 'File Not Found') {
			tr.style.backgroundColor = '#FFA07A';			
		}
		
		td1.appendChild(text1);
		td2.appendChild(text2);
		td3.appendChild(text3);
		td4.appendChild(text4);
		td5.appendChild(text5);
		td6.appendChild(text6);
		td7.appendChild(text7);
		
		tr.appendChild(td1);
		tr.appendChild(td2);
		tr.appendChild(td3);
		tr.appendChild(td4);
		tr.appendChild(td5);
		tr.appendChild(td6);
		tr.appendChild(td7);
		document.getElementById('tbodyFailedBit').appendChild(tr);	
	}
	
	var elmnt = document.getElementById("tbodyFailedBit");
    elmnt.scrollIntoView();
}

var STATUS;

$(document).on('click', '.rowOnClickBit', function(){
	
	
	var str = COMPAREID + ":" + RUNID + ":" + this.id;
	
	STATUS = this.value;
	var request = new XMLHttpRequest();
	request.open("POST", 'CompareBitLog', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//







(str);
	//alert('CompareId='+id);
	//alert("Test Cases Run Send to MZ.");
	TESTCASEID = this.name;
	
	request.onreadystatechange = function() {
		if (request.readyState==4 && request.status==200) {
			if(JSON.parse(request.responseText) == null){
				alert("No Data Found");
			}else{
				var testScenario = JSON.parse(request.responseText);
				compareBit(testScenario);
			}
		}
	}
});


function compareBit(testScenario){

	//alert("modal");
	document.getElementById('comment1').value = "";
	document.getElementById('comment2').value = "";


	//alert(STATUS);
	if(testScenario.mismatch != null){
		var data = testScenario.mismatch;
		var result = "KEY:: " + KEY;
		for(var j=0;j<data.length;j++){
			var hexx = data[j];
			//console.log("desc Str: " + str);
			var hex = hexx.toString();//force conversion
			var str = '';
			for (var i = 0; (i < hex.length && hex.substr(i, 2) !== '00'); i += 2){
				str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
				//console.log("str: " + str);
			}
			result = result + "<br />" + j + ":: " + str;
		}
		document.getElementById('misMatch').innerHTML = result;
	}
	document.getElementById('ENVOLD').innerHTML = "RUNID: " + testScenario.desc1; 
	document.getElementById('ENVNEW').innerHTML = "RUNID: " + testScenario.desc2;
	
	var bitLog = testScenario.xmlLog1;
	if(bitLog != null){
		var array = bitLog.split(",");
		array.sort();
		var finalBitLog = array[0];
		for(var i=1; i<array.length; i++){
			var temp = array[i];
			temp = temp.replace("[","");
			temp = temp.replace("]","");
			temp = temp.replace("{","");
			temp = temp.replace("}","");
			finalBitLog = finalBitLog + "\n" + temp;
		}
		document.getElementById('comment1').value = finalBitLog;
	}
	
	var bitLog1 = testScenario.xmlLog2;
	if(bitLog1 != null){
		var array1 = bitLog1.split(",");
		array1.sort();
		var finalBitLog1 = array1[0];
		for(var i=1; i<array1.length; i++){
			var temp = array1[i];
			temp = temp.replace("[","");
			temp = temp.replace("]","");
			temp = temp.replace("{","");
			temp = temp.replace("}","");
			finalBitLog1 = finalBitLog1 + "\n" + temp;
		}
		document.getElementById('comment2').value = finalBitLog1;
	}
	$('#myModal').modal({show:true});
}
	
function loadCompareData(itemData){
	var ComparisonMismatchExport = document.getElementById('ComparisonMismatchExport');
	var CmpMismatch = document.getElementById('CmpMismatch');
	ComparisonFailedRun.style.display = 'none';
	ComparisonNoRun.style.display = 'none';
	CmpMismatch.style.display = 'none'; 
	//var NoRunCases = document.getElementById('NoRunCases);
	//NoRunCases.style.display = 'none'; 
	//ComparisonMismatchExport.style.display = 'none';
	$('#tblSummary').empty();
	$('#tbodyFailed').empty();
	$('#tbodyPassed').empty();
	$('#tbodyNoRun').empty();
	$('#svgChart').empty();
	FailedCases = [];
	NoRunCases = [];
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
	
	var countPass = 0, countFail = 0, countCurr = 0, countPrev = 0, countOther = 0, improper = 0;
	
	if(itemData == null){
		alert("No Data in DB");
		return;
	}
	
	var lgth = itemData.length;
			
	for(var j=0;j<lgth;j++){
		
		var tr = document.createElement('tr');
		tr.value = itemData[j].status;
		tr.id = itemData[j].testCaseId;
		var td1 = document.createElement('td');
		var td2 = document.createElement('td');
		var td3 = document.createElement('td');
		var td4 =  document.createElement("input");
		//td4.type = "button";
		//td4.name = "Hello";
		//td4.value = "Ignore Error";

		var text1 = document.createTextNode(itemData[j].testCaseId);
		var text2 = document.createTextNode(itemData[j].description);
		var text3 = document.createTextNode(itemData[j].status);
		
		td1.appendChild(text1);
		td2.appendChild(text2);
		td3.appendChild(text3);
		
		tr.appendChild(td1);
		tr.appendChild(td2);
		tr.appendChild(td3);


		if (itemData[j].status == 'Failed'){
			//tr.appendChild(td4);			
			tr.className = 'rowFailOnClick';			
			countFail = countFail + 1;
			tr.name = itemData[j].testCaseId;
			if(tr.name != '1'){
				FailedCases.push(tr.name);
			}
		}else if (itemData[j].status == 'Passed'){
			countPass = countPass + 1;
		}else if (itemData[j].status == 'No Current Run'){
			countCurr = countCurr + 1;
			NoRunCases.push(itemData[j].testCaseId);
		}else if (itemData[j].status == 'No Previous Run'){
			countPrev = countPrev + 1;
			NoRunCases.push(itemData[j].testCaseId);
		}else if (itemData[j].status == 'Improper Execution'){
			improper = improper + 1;
			tr.className = 'rowFailOnClick';
			tr.name = itemData[j].testCaseId;
			NoRunCases.push(itemData[j].testCaseId);
		}else {
			countOther = countOther + 1;
		}
		document.getElementById('tblSummary').appendChild(tr);
	}
	
	var arrayName = [];
	var arrayValue = [];
	
	if(countPass > 0){
		arrayName.push("Passed");
		arrayValue.push(countPass);
	}
	if(countFail > 0){
		arrayName.push("Failed");
		arrayValue.push(countFail);
		ComparisonFailedRun.style.display = 'block';
		//ComparisonMismatchExport.style.display = 'block';
		CmpMismatch.style.display = 'block';
	}
	if(countCurr > 0){
		ComparisonNoRun.style.display = 'block';
		arrayName.push("No Current Run");
		arrayValue.push(countCurr);
	}
	if(countPrev > 0){
		ComparisonNoRun.style.display = 'block';
		arrayName.push("No Previous Run");
		arrayValue.push(countPrev);
	}
	if(improper > 0){
		ComparisonNoRun.style.display = 'block';
		arrayName.push("Improper Exec");
		arrayValue.push(improper);
	}
	if(countOther > 0){
		arrayName.push("Others");
		arrayValue.push(countOther);
	}
	drawBarChart(arrayName,arrayValue,1);
	//alert("FailedCases array length = "+FailedCases.length);
	//alert("NoRunCases array length = "+NoRunCases.length);
}


$(document).on('click', '.rowFailOnClick', function(){
	
	var FailedTestCaseResponse = document.getElementById('FailedTestCaseResponse');
	FailedTestCaseResponse.style.display = 'block';
	
	var myBtnBack = document.getElementById('myBtnBack');
	myBtnBack.style.display = 'block';
	
	var FailedTestCaseBit = document.getElementById('FailedTestCaseBit');
	FailedTestCaseBit.style.display = 'none';
	
	var elmnt = document.getElementById(this.id);
	//alert("elmnt " +elmnt );
	OFFSETTOP = position(elmnt);	
	//alert(OFFSETTOP);
	var str = COMPAREID + ":" + this.name;
	alert(str);
	var request = new XMLHttpRequest();
	request.open("POST", 'CompareTestCaseData', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert('CompareId='+id);
	//alert("Test Cases Run Send to MZ.");
	TESTCASEID = this.name;
	
	request.onreadystatechange = function() {
		if (request.readyState==4 && request.status==200) {
			if(JSON.parse(request.responseText) == null){
				alert("No Data Found");
			}else{
				var testScenario = JSON.parse(request.responseText);
				//alert(testScenario.compareReport);
				loadCompareTestCaseData(testScenario);
			}
		}
	}
});

var ID;
var arraydetails;
function loadCompareTestCaseData(response){
	$('#tbodyFailed').empty();
	$('#tbodyPassed').empty();
	$('#tbodyNoRun').empty();
	//alert(this.name);
	var itemData = response.compareReport;
	//alert("CompareId" + response.compareId);
	var lgth = itemData.length;
	//alert(lgth);
	
	for(var j=0;j<lgth;j++){
		//alert("One Row - " + itemData[j]);
		var tr = document.createElement('tr');
		tr.name = itemData[j].testCaseId;
		tr.value = itemData[j].testStep;
		tr.style.border = '1px solid black';
		tr.id = TESTCASEID + " And testStep: " + itemData[j].testStep;
		ID = tr.id;
		var td1 = document.createElement('td');
		//td1.style.border = '2px solid black';
		var td2 = document.createElement('td');
		var td3 = document.createElement('td');
		var td4 = document.createElement('td');
		var td5 = document.createElement('td');
		//var td6 = document.createElement('td');
		//td5.style.border = '2px solid black';
		//var td7 = document.createElement("input");
		//td7.type = "button";
		//arraydetails = response.compareId+":"+itemData[j].testCaseId+":"+itemData[j].testStep;
		//alert("td7.name " +td7.name);
		//td7.value = "Ignore Error";
		//td7.onclick = ignoreMismatchError;
		
		var text1 = document.createTextNode(TESTCASEID);
		var tstStep = "Step#" + itemData[j].testStep;
		var text2 = document.createTextNode(tstStep);
		var text3 = document.createTextNode(itemData[j].previousLog);
		var text4 = document.createTextNode(itemData[j].currentLog);
		var text5 = document.createTextNode(itemData[j].stepStatus);
		//var text6 = document.createButton("Ignore");


		
		td1.appendChild(text1);
		td2.appendChild(text2);
		td3.appendChild(text3);
		td4.appendChild(text4);
		td5.appendChild(text5);
		//td6.appendChild(text6)
		tr.appendChild(td1);
		tr.appendChild(td2);
		tr.appendChild(td3);
		tr.appendChild(td4);
		tr.appendChild(td5);
		//tr.appendChild(td6);

		if(itemData[j].stepStatus == 'Not Matched'){
			tr.className = 'rowOnClick';
			arraydetails = response.compareId+":"+itemData[j].testCaseId+":"+itemData[j].testStep;
			//alert(itemData[j].testStep);
			tr.style.backgroundColor = '#F08080';
			//tr.appendChild(td7);
		}

		document.getElementById('tbodyFailed').appendChild(tr);	
	}
	//alert("alert "+arraydetails);
	var elmnt = document.getElementById("tbodyFailed");
    elmnt.scrollIntoView();
	 
}

function ignoreMismatchError(){
	/*alert("desp "+desp);
	//alert('Hi ' + this.name);
	alert("cmpID" +cmpID);
	alert("stepID" +stepID);
	alert("Caseid" +Caseid);*/
	if(cmpID != null && desp !=null && stepID !=null && Caseid!=null){
	var sendReq;	
	sendReq=cmpID + "|"+ Caseid + "|" + stepID + "|" + desp;
	alert("sendReq "+sendReq);
	alert("Error Ignore Request Submitted");
	var request = new XMLHttpRequest();
	request.open("POST", 'IgnoreCompareMismatch', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(this.name);
	request.onreadystatechange = function() {
		if(request.readyState==4 && request.status==200) {
				if(JSON.parse(request.responseText) == null){
					alert("Request Failed!");
				}	else	{
					var response = request.responseText;
					//alert(request.responseText);
					alert("Step Error Ignored in Comparision");
				}
			}
		}
	}else{
		desp == null;
		cmpID == null;
		stepID == null;
		Caseid == null;
	}
	
}

function scrollBack(){
	//alert("Clicked BAck");
	
	//alert(ID);
	//OFFSET=100;
	var elmnt = document.getElementById('tblSummary').rows;
	//alert(elmnt);
	for (var i = 0; i < elmnt.length; i++) {
		var id = elmnt[i].id;
        if (id == ID){
			alert(id + "/" + ID);
			$('html,body').delay(1000).animate({scrollTop:elmnt[i].offsetTop}, 500);
			
		}
	}
    //elmnt.scrollIntoView();
}

var cmpID;
var stepID;
var Caseid;
$(document).on('click', '.rowOnClick', function(){
	
	var str = RUNID + ":" + this.name + ":" + this.value + ":" + COMPAREID;
	cmpID = null;
	stepID = null;
	Caseid = null;
	cmpID = COMPAREID;
	stepID= this.value;
	Caseid = this.name;
	//alert("yo"+str);
	var request = new XMLHttpRequest();
	request.open("POST", 'CompareXMLlog', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	var rowonClick = this.id;
	//alert("New Fail" +rowonClick);
	//alert('CompareId='+id);
	//alert("Test Cases Run Send to MZ.");
	TESTCASEID = this.name;
	//alert("yo");
	var comm1 = document.getElementById('comment1');
	var comm2 = document.getElementById('comment2');
	var mymodal = document.getElementById('myModal');
	$('#comm1').empty();
	$('#comm2').empty();
	//alert("My Modal");
	$('#mymodal').empty();
	request.onreadystatechange = function() {
		if (request.readyState==4 && request.status==200) {
			if(JSON.parse(request.responseText) == null){
				alert("No Data Found");
			}else{
				 var testScenario = JSON.parse(request.responseText);
				$('#myModal').modal({show:true});
				compare(testScenario);
			}
		}
	}
});
var desp;
function compare(testScenario){
	document.getElementById('ENVOLD').innerHTML = "RUNID: " + testScenario.desc1; 
	document.getElementById('ENVNEW').innerHTML = "RUNID: " + testScenario.desc2; 
	document.getElementById('comment1').value = testScenario.xmlLog1;
	document.getElementById('comment2').value = testScenario.xmlLog2;
	
	mismatchID = document.getElementById('misMatch');
	$('#misMatch').empty();

		
	var tbl = document.createElement("table");
	tbl.id = "mytableId";
	//tbl.style.width= "20px";
	//alert("width "+tbl.style.width);
	if(testScenario.mismatch != null){
		var data = testScenario.mismatch;
		var result = '';
		//var tbl = document.createElement("table");
		//tb1.style.border="1px solid red";
		//tb1.setAttribute("border", "1");
		var tr2 = document.createElement('tr');
		var td1 = document.createElement('td');
		var td2 = document.createElement('td');
		var td3 = document.createElement('td');
		var td4 = document.createElement('td');
		var td5 = document.createElement('td');
		var srno = document.createTextNode("Sr.No");
		var descp = document.createTextNode("Decription");
		var oldenv = document.createTextNode("Old RUN");
		var newenv = document.createTextNode("New RUN");
		var ignoreerror = document.createTextNode("Ignore Error");
		td1.appendChild(srno);
		td2.appendChild(descp);
		//td2.style.word-wrap = "break-word";
		//td2.id = "myDIV";
		//document.getElementById("myDIV").style.wordWrap = "break-word";
		td3.appendChild(oldenv);
		td4.appendChild(newenv);
		td5.appendChild(ignoreerror);
		tr2.appendChild(td1);
		tr2.appendChild(td2);
		tr2.appendChild(td3);
		tr2.appendChild(td4);
		tr2.appendChild(td5);
		tbl.appendChild(tr2);
		for(var j=0;j<data.length;j++){
			var str = data[j];
			//alert("str "+str);			
			//var hexx = data[j];
			
			result = result + "<br />" + j + ":: " + str;
			//var desciption = result.split("::");
			var value = str.split("|");
			//alert("value" + value[0]);
			//var oldnnew = value[1].split("|");
			//var newvalue = oldnnew[1].split("<");
			
			
			var tr = document.createElement('tr');
			var td21 = document.createElement('td');
			var td22 = document.createElement('td');
			var td23 = document.createElement('td');
			var td24 = document.createElement('td');
			var td7 = document.createElement("input");
			//var despArray = value[0]+value[1];
			td7.name = value[0]+"|"+value[1];
			td7.className = 'rowOnClickIgnore';
			//alert("despArray "+despArray);
			td7.type = "button";
			td7.value = "Ignore Error";
			//desp = despArray[j];
		    //td7.onclick = ignoreMismatchError;
			
			var srno = document.createTextNode(j);
			var descp = document.createTextNode(value[0]+"|"+value[1]);
			var oldenv = document.createTextNode(value[2]);
			var newenv = document.createTextNode(value[3]);
			td21.appendChild(srno);
			td22.appendChild(descp);
			td22.id = "myDIV";
			td23.appendChild(oldenv);
			td24.appendChild(newenv);
			tr.appendChild(td21);
			tr.appendChild(td22);
			tr.appendChild(td23);
			tr.appendChild(td24);
			tr.appendChild(td7);
			tr.id = j;
			//td22.style.word-wrap = "break-word";
			//alert(td22.getAttribute('width'))
			//td22.setAttribute("width","200px");
			tbl.appendChild(tr);
			
			
			/*var despArray = value[0]+value[1];
			tr.className = 'rowOnClickIgnore';
			tr.name = value[0]+value[1];
			alert("despArray "+despArray);
			td7.type = "button";
			td7.value = "Ignore Error";
			//desp = despArray[j];
		    td7.onclick = ignoreMismatchError;*/
			
		}

				
		
		//alert("table" + tbl);
		tbl.setAttribute("border", "1");
		mismatchID = document.getElementById('misMatch');
		mismatchID.appendChild(tbl);
		//document.getElementById('misMatch').innerHTML = result;
	}
}
$(document).on('click', '.rowOnClickIgnore', function(){
	
	desp = this.name ;
	//alert("despnewww "+desp);	
	if(cmpID != null && desp !=null && stepID !=null && Caseid!=null){
	var sendReq;	
	sendReq=cmpID + ":"+ Caseid + ":" + stepID + ":" + desp;
	alert("Ignore Request "+sendReq);
	//alert("Ignore Request ");
	var request = new XMLHttpRequest();
	request.open("POST", 'IgnoreCompareMismatch', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(sendReq);
	request.onreadystatechange = function() {
		if(request.readyState==4 && request.status==200) {
			//alert("Resp "+request.responseText);
				if(request.responseText == null){
					alert("Request Failed!");
					}else{
					var response = request.responseText;
					//alert(request.responseText);
					alert("Step Error Ignored in Comparision");
				}
			}
		}
		desp == null;
	}else{
		desp == null;
		cmpID == null;
		stepID == null;
		Caseid == null;
	}


});

function fillXMLModal(response){
	var comm1 = document.getElementById('comment1');
	var comm2 = document.getElementById('comment2');
	var mymodal = document.getElementById('myModal');
	$('#comm1').empty();
	$('#comm2').empty();
	alert("My Modal");
	$('#mymodal').empty();


	alert(testScenario.xmlLog1);
	alert(testScenario.xmlLog2);
	
	document.getElementById('comment1').value = testScenario.xmlLog1;
	document.getElementById('comment2').value = testScenario.xmlLog2;
	
	var labelBody = document.getElementById('misMatch');
	var misMatchData = testScenario.mismatch;
	if(misMatchData == null){
		labelBody.innerHTML = "No Data.";
	}else{
		labelBody.innerHTML = misMatchData;
	}
	$('#myModal').modal({show:true});
}


$(function() {
	$('textarea[id$=comment1]').scroll(function() {
		$('textarea[id$=comment2]')
		.scrollTop($('textarea[id$=comment1]').scrollTop());
	});
});


$(function() {
	$('textarea[id$=comment2]').scroll(function() {
		$('textarea[id$=comment1]')
		.scrollTop($('textarea[id$=comment2]').scrollTop());
	});
});

function myFunction() {
	var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("LI");
	//alert("Hi:" + li[5].getElementsByTagName("a")[0]);
	ul.style.display = 'block';
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("A")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = '';
        } else {
            li[i].style.display = 'none';

        }
    }
}



$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});


$(document).on('click', '.rectOnClick1', function(){
	//alert(this.id);
	
    document.getElementById("myBtn").style.display = "block";
	//var tag = document.getElementsByTagName('tr');
	var tag = document.getElementById('tblSummary').rows;
	alert(tag.length);
	for(var i=0; i<tag.length; i++){
		if(tag[i].value == this.id){
			//alert("We almost Got This: " + tag[i].id);
			//alert(tag[i].value);
			tag[i].scrollIntoView(true);
			break;
		}
	}
	//alert(tag[i].id);
    //elmnt.scrollIntoView();	
});

$(document).on('click', '.rectOnClick2', function(){
	//alert(this.id);
	//var elmnt = document.getElementById(this.id);
    document.getElementById("myBtn").style.display = "block";
	
	//var tag = document.getElementsByTagName('tr');
	var tag = document.getElementById('tblBitSummary').rows;
	//alert(tag.length);
	for(var i=0; i<tag.length; i++){
		if(tag[i].value == this.id){
			//alert("We almost Got This: " + tag[i].id);
			//alert(tag[i].value);
			tag[i].scrollIntoView(true);
			break;
		}
	}
	//alert(tag[i].id);
    //elmnt.scrollIntoView();	
});


window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 1000 || document.documentElement.scrollTop > 1000) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
	
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
	//alert("Go Top");
    document.body.scrollTop = 275;
    document.documentElement.scrollTop = 275;
	
	var myBtnBack = document.getElementById('myBtnBack');
	myBtnBack.style.display = 'none';
}

function backFunction() {
	//alert("Go Back");
	var FailedTestCaseBit = document.getElementById('FailedTestCaseBit');
	FailedTestCaseBit.style.display = 'none';

	var FailedTestCaseResponse = document.getElementById('FailedTestCaseResponse');
	FailedTestCaseResponse.style.display = 'none';
    //alert(OFFSETTOP);
	var scrollTo = OFFSETTOP - 50;
	document.body.scrollTop = scrollTo;
    document.documentElement.scrollTop = scrollTo;	
	
	var myBtnBack = document.getElementById('myBtnBack');
	myBtnBack.style.display = 'none';
}

function position(element) {
    var top = 0, left = 0;
    do {
        top += element.offsetTop  || 0;
        left += element.offsetLeft || 0;
        element = element.offsetParent;
    } while(element);

    return top;
}


var dev2;// = document.getElementById("DEV2");
var st2; //= document.getElementById("ST2");
var dev1;

function loadListElements(){
	if(!dev2)
		dev2 = document.getElementById("DEV2");
	
	if(!st2)
		st2 = document.getElementById("ST2");
	
	if(!dev1)
		dev1 = document.getElementById("DEV1");

	if(dev2){
		dev2.addEventListener("click", RunFailedComparisonCasesDev2);
	}
	if(st2){
		st2.addEventListener("click", RunFailedComparisonCasesSt2);
	}
	if(dev1){
		dev1.addEventListener("click", RunFailedComparisonCasesDev1);
	}
	//alert("hi");
}

function loadListElementsNoRun(){
	if(!dev2)
		dev2 = document.getElementById("DEV22");
	
	if(!st2)
		st2 = document.getElementById("ST22");
	
	if(!dev1)
		dev1 = document.getElementById("DEV12");

	if(dev2){
		//RUNNORUNENV = "DEV2"
		dev2.addEventListener("click", RunNoRunComparisonCasesDev2);
	}
	if(st2){
		st2.addEventListener("click", RunNoRunComparisonCasesSt2);
		//RUNNORUNENV = "ST2"
	}
	if(dev1){
		dev1.addEventListener("click", RunNoRunComparisonCasesDev1);
		//RUNNORUNENV = "DEV1"
	}
	//alert("hi");
}


function myScript1(e){
    alert("Dev-2");       
}
function myScript2(e){
	alert("ST-2");
}

function ComparisonMismatchExport(range){
	RANGE = range;
	var str = COMPAREID+":"+range;
	alert("Downloading Comparision Mismatch Report for "+range);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ComparisonMismatchExport", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				//alert(request.responseText);
				var data = JSON.parse(request.responseText);
				//alert(data);
				exportMISMATCHReport(data);			
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
}

function exportMISMATCHReport(output){
	//alert("hi");
	var data = output.reportMISMATCH
	var lgth = data.length;
	//alert(data[0].testCaseId);
	const rows = new Array();
	for(var j=0; j<lgth; j++){
		//alert(data[j].serialNo);
		rows[j] = new Array(data[j].serialNo, data[j].compareId, data[j].testCaseId, data[j].stepId, data[j].stepName, data[j].mismatchDesc, data[j].value1, data[j].value2);
	}
	//alert(rows);
	let csvContent = "data:text/csv;charset=utf-8,";
	rows.forEach(function(rowArray){
	   let row = rowArray.join(",");
	   csvContent += row + "\r\n";
	});
	//alert(csvContent);
	var encodedUri = encodeURI(csvContent);
	//window.open(encodedUri);
	var link = document.createElement("a");
	link.setAttribute("href", encodedUri);
	link.setAttribute("download", "reportCompareMismatch_" + COMPAREID + "_" + RANGE + ".csv");
	link.innerHTML= "Click Here to download";
	document.body.appendChild(link); // Required for FF

	link.click();
}


function populateMismatchDropdown(rowCount){
	//first remove all the child nodes of the dropdown list
	var myNode = document.getElementById("MismatchRange");
	while (myNode.firstChild) {
    		myNode.removeChild(myNode.firstChild);
	}	
	
	//now populate the list with new range
	for(var i = 0; i < rowCount; i= i + 3000){
		//alert("bro");
		opt1 = document.createElement("option");
		//opt1.value = "dummy Text";
		var high = i+3000;
		if(high > rowCount){
			high = rowCount;
		}	
		opt1.value = i + "-" + high;
		opt1.text = opt1.value;
		document.getElementById('MismatchRange').appendChild(opt1);	
	}
}

function RunFailedComparisonCasesDev2(){
	var str = "DEV2;" + COMPAREID + ";" + FailedCases[0];
	for(var i=1; i<FailedCases.length; i++){
		str = str + ";" + FailedCases[i];
	}
	//alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ComparisonFailedReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				//location.reload(false);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
}
function RunNoRunComparisonCasesDev2(){
	var str = "DEV2;" + COMPAREID + ";" + NoRunCases[0];
	for(var i=1; i<NoRunCases.length; i++){
		str = str + ";" + NoRunCases[i];
	}
	//alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ComparisonNoRunReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				//location.reload(false);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
}
function RunNoRunComparisonCasesDev1(){
	var str = "DEV1;" + COMPAREID + ";" + NoRunCases[0];
	for(var i=1; i<NoRunCases.length; i++){
		str = str + ";" + NoRunCases[i];
	}
	//alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ComparisonNoRunReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				//location.reload(false);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
}
function RunNoRunComparisonCasesSt2(){
	var str = "ST2;" + COMPAREID + ";" + NoRunCases[0];
	for(var i=1; i<NoRunCases.length; i++){
		str = str + ";" + NoRunCases[i];
	}
	//alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ComparisonNoRunReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				//location.reload(false);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
}

function RunNoRunComparisonCases(env){

	var str = env + ";" + COMPAREID + ";" + NoRunCases[0];
	for(var i=1; i<NoRunCases.length; i++){
		str = str + ";" + NoRunCases[i];
	}
	alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ComparisonNoRunReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				//location.reload(false);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}

}

function RunFailedComparisonCasesDev1(){
	var str = "DEV1;" + COMPAREID + ";" + FailedCases[0];
	for(var i=1; i<FailedCases.length; i++){
		str = str + ";" + FailedCases[i];
	}
	//alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ComparisonFailedReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				//location.reload(false);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}

}

function RunFailedComparisonCasesSt2(){
	var str = "ST2;" + COMPAREID + ";" + FailedCases[0];
	for(var i=1; i<FailedCases.length; i++){
		str = str + ";" + FailedCases[i];
	}
	//alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ComparisonFailedReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				//location.reload(flase);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}

}