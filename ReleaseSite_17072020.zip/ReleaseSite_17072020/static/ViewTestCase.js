function createXmlHttp() {
	var xhr;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xhr=new XMLHttpRequest();
	} else {// code for IE6, IE5
		xhr=new ActiveXObject('Microsoft.XMLHTTP');
	}
	return xhr;
}

function loadViewTestCasePage() {
	//alert("yo");
	var xhr = createXmlHttp();
	xhr.onreadystatechange=function() {
		if (xhr.readyState==4 && xhr.status==200) {
			var testScenario = JSON.parse(xhr.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			//alert("hi");
			addTestScenarioRow(mainPanel, testScenario.content);
		}
	}
	
	xhr.open('GET', 'ViewTestCaseDetails.html?', true);
	xhr.send();
}
function updateTestCaseStatus(readObj){
	for(i=0;tbodyFailed.rows[i].cells[2].innerHTML!="VALID";i++){
			if(tbodyFailed.rows[i].cells[2].innerHTML=="PENDING"){
				var x = tbodyFailed.rows[i].cells[0];
				console.log("Content " + x.innerHTML);
				var y = tbodyFailed.rows[i].cells[2];
				console.log("Content status " + y.innerHTML);
				var obj = JSON.parse(readObj);
				console.log(obj);
				console.log("readObject status" + obj.testCaseId);
				shareInfoLen = Object.keys(obj).length;
				console.log("shareInfoLen" +shareInfoLen);
				if(x == obj.testCaseId){
						tbodyFailed.rows[i].cells[2].innerHTML = obj.status;
						console.log("ReadObj" +obj.status);
				}
				else{

						tbodyFailed.rows[i].cells[2].innerHTML = obj.status;
				}
			}
		}
/*
	//var x=document.getElementById('tbodyFailed');//.rows[0];
	var x = tbodyFailed.rows[0].cells[0];
	console.log("Content " + x.innerHTML);
	var y = tbodyFailed.rows[0].cells[2];
	console.log("Content status " + y.innerHTML);
//	var y=x[2];
	//console.log("Table row0 cell 2 " +y);
	var obj = JSON.parse(readObj);
	console.log(obj);
	console.log("readObject status" + obj.testCaseId);
	shareInfoLen = Object.keys(obj).length;
	console.log("shareInfoLen" +shareInfoLen);
	//var iSize = _size.(obj);
	//console.log("Json Array Size : " +iSize);
	//for (var i = 0; i < item.length; i++) {
	if(x == obj.testCaseId){
		//alert("Before " + tbodyFailed.rows[0].cells[2].innerHTML);
		tbodyFailed.rows[0].cells[2].innerHTML = obj.status;
		//alert("After " + tbodyFailed.rows[0].cells[2].innerHTML);
		console.log("ReadObj" +obj.status);
	}
	else{

		//alert("Before " + tbodyFailed.rows[0].cells[2].innerHTML);
		tbodyFailed.rows[0].cells[2].innerHTML = obj.status;
                //alert("After " + tbodyFailed.rows[0].cells[2].innerHTML);
	}*/
/*
	var btn = document.createElement("BUTTON");
        btn.value = obj.testCaseId;
	var td5 = document.createElement('td');
	if(tbodyFailed.rows[0].cells[2].innerHTML == 'ERROR'){
                        var span = document.createElement ("span");
                        span.className = "glyphicon glyphicon-sunglasses";
                        btn.appendChild(span);
                        btn.className = 'btn btn-info btn-sm';
                        var t = document.createTextNode("View Details");
                        btn.appendChild(t);
                        btn.name = tbodyFailed.rows[0].cells[2].errorDetail;
                        btn.id = "onClickView";
                        td5.appendChild(btn);

                        var btn1 = document.createElement("BUTTON");
                        var t = document.createTextNode("Delete");
                        btn1.appendChild(t);

                        var span1 = document.createElement ("span");
                        span1.className = "glyphicon glyphicon-trash";
                        btn1.appendChild(span1);

                        btn1.id = "onClickDelete";
                        btn1.name = tbodyFailed.rows[0].cells[2].testcaseid;
                        btn1.value = tbodyFailed.rows[0].cells[2].testcaseid;
                        btn1.className = "btn btn-info btn-sm";

                        td5.appendChild(btn1);

                }*/
	console.log("Inside Js" + readObj);


}
function addTestScenarioRow(panel, item) {
	//alert(item.length);
	countTestCase = 0;
	for (var i = 0; i < item.length; i++) {
		//alert(item[i]);
		if(item[i].status1 == "OBSELETE"){

			
		}
		var tr = document.createElement('tr');
		tr.id = item[i].testcaseid;
		tr.name = item[i].testStep;
		tr.style.border = '2px solid black';
		
		var td1 = document.createElement('td');
		var td2 = document.createElement('td');
		//var td3 = document.createElement('td');
		var td4 = document.createElement('td');
		var td5 = document.createElement('td');
		
		var text1 = document.createTextNode(item[i].testcaseid);
		var text2 = document.createTextNode(item[i].description);
		//var text3 = document.createTextNode(item[i].filename);
		var text4 = document.createTextNode(item[i].status1);
		
		var btn = document.createElement("BUTTON");
		btn.value = item[i].testcaseid;
			
		if(item[i].status1 == 'ERROR'){
			var span = document.createElement ("span");
			span.className = "glyphicon glyphicon-sunglasses";
			btn.appendChild(span);
			btn.className = 'btn btn-info btn-sm';
			var t = document.createTextNode("View Details");
			btn.appendChild(t);       
			btn.name = item[i].errorDetail;	
			btn.id = "onClickView";
			td5.appendChild(btn);		

			var btn1 = document.createElement("BUTTON");        		
			var t = document.createTextNode("Delete");		
			btn1.appendChild(t);
			
			var span1 = document.createElement ("span");
			span1.className = "glyphicon glyphicon-trash";
			btn1.appendChild(span1);
			
			btn1.id = "onClickDelete"; 
			btn1.name = item[i].testcaseid;
			btn1.value = item[i].testcaseid;
			btn1.className = "btn btn-info btn-sm";
			
			td5.appendChild(btn1);
			
		}else if(item[i].status1 == 'VALID'){
			countTestCase = countTestCase + 1;
			btn.className = 'btn btn-primary';
			var t = document.createTextNode("AddAssertion");
			btn.appendChild(t);
			btn.id = "AddAssertion";
			td5.appendChild(btn);
			
			var btn1 = document.createElement("BUTTON");
			btn1.value = item[i].testcaseid;
			btn1.className = 'btn btn-primary';
			var t1 = document.createTextNode("Add Prerequisite TestCaseId");
			btn1.appendChild(t1);
			btn1.id = "PreRequisite";
			//td5.appendChild(btn1);
		}
				
		td1.appendChild(text1);
		td2.appendChild(text2);
		//td3.appendChild(text3);
		td4.appendChild(text4); 

		td1.style.border = '1px solid black';
		td2.style.border = '1px solid black';
		//td3.style.border = '1px solid black';
		td4.style.border = '1px solid black';
		td5.style.border = '1px solid black';
		
		//td3.className='BreakWord';
		
		tr.appendChild(td1);
		tr.appendChild(td2);
		//tr.appendChild(td3);
		tr.appendChild(td4);
		tr.appendChild(td5);
		
		document.getElementById('tbodyFailed').appendChild(tr);
		
	}
	var labelBody = document.getElementById('ValidTestCase');
	labelBody.innerHTML = "Total Valid Test Case = " + countTestCase;
}


$(document).on('click', '#onClickView', function(){
	//alert("Hi");
	var result = "For TestCaseId: " + this.value + "\n";
	for(var i=0;i<this.name.length;i++){
		result = result + this.name[i];
	}
	alert(result);
});

$(document).on('click', '#onClickDelete', function(){
	//alert("Hi");
	var result = "Delete TestCaseId: " + this.value + "\n";
	//alert(result);
	
	var request = new XMLHttpRequest();
	request.open("POST", "DeleteTestCase", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(this.value);
	//alert("Test Cases Run Send to MZ." + testCases);
	alert("Request Send to MZ.\n" + result);
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);
				location.reload(true);
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
});

$(document).on('hidden.bs.modal', function (e) {
	//alert("Hi1");
    var Parent = document.getElementById('tbody1');
	while(Parent.hasChildNodes())
	{
	   Parent.removeChild(Parent.firstChild);
	}
});


$(document).on('click', '#AddAssertion', function(){
	//alert("Hi");
	//location.href = "AddAssertion.html";
	var id = this.value;        
    if (id != undefined && id != null) {
        //window.location = '/AddAssertion=' + id;
		//window.location = "AddAssertion.html?"+id;
		window.location.href = "/AddAssertion.html?TestCaseId="+id;
	}
});


$(document).on('click', '#PreRequisite', function(){
	//alert("Hi");
	var buttonSub = document.getElementById('submitPre');
	buttonSub.name = this.value;
	
	$('#myModal1').modal({show:true});
});

$(document).on('click','#submitPre', function(){
	
	if(SFieldInput.value == null || SFieldInput.value == ""){
		alert("Please Enter PreRequisite TestCaseId\n");
		return;
	}
	
	var result = this.name + ":" + SFieldInput.value;
	alert(result);
	var request = new XMLHttpRequest();
	request.open("POST", "PreRequisiteTestCase", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(result);
	//alert("Test Cases Run Send to MZ." + testCases);
	alert("Request Send to MZ.\n");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);
				location.reload(true);
			}
			else{
				alert("Error response:" + request.responseText);
			}
		}
	}
	document.getElementById('SFieldInput').value = "";
	$('#myModal1').modal('hide');
});


$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
