function processSubmitTestRun(){
	alert("processSubmitTestRun");
	var checkboxresult = document.getElementById("myCheck");
	var result = validate();
	if(result != "True"){
		alert(result);
		return;
	}
	
	var description = document.getElementById("testDescription").value;
    var finalstring;
	if(checkboxresult.checked == true)
	{
		finalstring = description + ";" + "1"
	}else if(checkboxresult.checked == false)
	{
		finalstring = description + ";" + "0"
	}
	else{
		//do nothing
	}
	
	alert(description);
	var dropdown = document.getElementById("baseLine");
	var dropdownValue = dropdown.options[dropdown.selectedIndex].text;
	
	var request = new XMLHttpRequest();
	request.open("POST", "http://10.137.167.12:8085/Stepsgte1000:" + dropdownValue, true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(finalstring);
	//alert("Test Cases Run Send to MZ." + description);
	alert("Test Cases Run Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);
				
				var labelBody = document.getElementById('runId');
				labelBody.innerHTML = request.responseText;				
			}
			else
				alert("Response:" + request.responseText);
		}
	}
}


function validate(){
	//alert("Inside validate");
	var result = "True";
	
	var dropdown = document.getElementById("baseLine");
	var dropdownValue = dropdown.options[dropdown.selectedIndex].text;
	//alert(dropdownValue);
	if( dropdownValue == "--Select--"){
		result = "Please select an Environment to Run.\n";
	}
	
	var minLength = 10;
	var txtBox = document.getElementById("testDescription").value;
	if(txtBox.length < minLength ){
		if(result == "True")
			result = "";
		result = result + "Incorect text length. Minimum 10 letters.\n";
	}
	
	//alert("result");
	return result;
}


$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
