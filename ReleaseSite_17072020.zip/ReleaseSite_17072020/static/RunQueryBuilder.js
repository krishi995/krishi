function createXmlHttp() {
	var xhr;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xhr=new XMLHttpRequest();
	} else {// code for IE6, IE5
		xhr=new ActiveXObject('Microsoft.XMLHTTP');
	}
	return xhr;
}

function loadRunQueryBuilder() {//intial on loading of page
	//alert("yo");
	var xhr = createXmlHttp();
	
	xhr.open('GET', 'RunQueryBuilder.html?', true);
	xhr.send();
	
	xhr.onreadystatechange=function() {
		if (xhr.readyState==4 && xhr.status==200) {
			var testScenario = JSON.parse(xhr.responseText);
			//alert("hi" +testScenario );
			addAttribute(testScenario.content);
		}
	}
}

function addAttribute(item){
	var rowcount = document.getElementById("tableData").rows.length;
	rowcount = rowcount + 1;
	//alert(item[0].testcaseid)
	var tr = document.createElement("tr");//tr is row
	tr.id = "TR"+rowcount;
	document.getElementById("tableData").appendChild(tr);
	var td = document.createElement("td");//td is column
	var columncount = document.getElementById('tableData').rows[0].cells.length;
	td.id = "TD"+columncount + "1";
	tr.appendChild(td);
	
	var label = document.createElement("label");
	var h4 = document.createElement("h4");
	//Create intial text 
	h4.textContent = "Select Attribute:";
    label.appendChild(h4);
    td.appendChild(label);
	
	var div = document.createElement("div");
	div.id = "searchDropDown"+rowcount;
	var input1 = document.createElement("input");
	//alert("Function to check" + input1);
	/*input1.type = "text";
	input1.id = "myInput";
	input1.onkeyup = myFunction();
	input1.placeholder = "Search for names..";
	input1.title = "Type in a name";
	*/
	input1.setAttribute("type", "text");
    input1.setAttribute("id", "myInput");
    input1.setAttribute("onkeyup", "myFunction()");
    input1.setAttribute("placeholder", "Type in a name");
    input1.setAttribute("title", "Search for names.."); 
	div.appendChild(input1);
	//Intial Ul with LI containg initial data
	var ul = document.createElement("ul");
	ul.id="myUL" + rowcount;
	div.appendChild(ul);
	td.appendChild(div);
	
	
	/*var td1 = document.createElement("td");
	td1.id = "TD"+rowcount + "2";
	tr.appendChild(td1);
	var ul1 = document.createElement("ul");
	ul1.setAttribute("id","myUL" + rowcount);
	ul1.setAttribute("class", "AttributeOptionOnClick");
	td.appendChild(ul);*/

	//Poultaling initial data in list format			
	for (var i = 0; i < item.length; i++) {	
	
		var li = document.createElement("LI");
		li.id = item[i].testcaseid;
		//li.value = item[i].testcaseid;
		//alert("OnClick");
		li.className = 'liOnClick';
		
		
		var elLink = document.createElement("A");
		var t = document.createTextNode(item[i].testcaseid);
		elLink.setAttribute("href", "#");
		elLink.appendChild(t);
		li.appendChild(elLink);
		ul.appendChild(li);
	}	
}

function myFunction(){
	var rowcount = document.getElementById("tableData").rows.length;
	var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
	//alert(input.value);
	if(input != null){
		//alert("Yo");
	    filter = input.value.toUpperCase();
		ul = document.getElementById("myUL"+ rowcount);
		//alert(ul);
		li = ul.getElementsByTagName("LI");
		//alert(li.length);
		//alert("Hi:" + li[0].getElementsByTagName("A")[0]);
		ul.style.display = 'block';
		for (i = 0; i < li.length; i++) {
			a = li[i].getElementsByTagName("A")[0];
			if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
				li[i].style.display = '';
			} else {
				li[i].style.display = 'none';
			}
		}	
	}
}

var QUERYSTRING = new Object();  //attribute, attributeOption, attributeSubOption, data,

$(document).on('click', '.liOnClick', function(){
	var rowcount = document.getElementById("tableData").rows.length;
	//alert(this.value);
	//alert(this.id);
	var myUL = document.getElementById('myUL' + rowcount);
	//do not display the UL
	myUL.style.display = 'none';
	
	$('#AttributeOptionId').empty();
	
	document.getElementById("myInput").value = this.id; //this.id select the id on click event and returns value
	QUERYSTRING.attribute = this.id;
	
	var request = new XMLHttpRequest();
	request.open("POST", "GetAttributeOption", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(this.id);
	//alert("Request To MZ: " + str);	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				//alert(request.responseText);
				var item = JSON.parse(request.responseText);
				loadAttributeOption(item.content);
			}
		}
	}
});

function loadAttributeOption(item){//Create second column to display result
	var rowcount = document.getElementById("tableData").rows.length;
	var td1 = document.createElement("td");
	var columncount = document.getElementById('tableData').rows[0].cells.length;
	td1.id = "TD"+rowcount + columncount;
	var tr1 = document.getElementById("TR"+rowcount);
	tr1.appendChild(td1);
	var ul1 = document.createElement("ul");
	ul1.setAttribute("id","myUL" + rowcount);
	//ul1.setAttribute("class", "AttributeOptionOnClick");
	td1.appendChild(ul1);
	//alert(item);
	//alert(item.length);
	
	for (var i = 0; i < item.length; i++) {	
		//alert(item[i]);
		//alert(item[i].type);
		//create second column with text 
		var li = document.createElement("LI");
		li.id = item[i].attribute + ":" + item[i].type;
		li.className = 'attributeOptionLiOnClick';
		
		var elLink = document.createElement("A");
		var t = document.createTextNode(item[i].attribute); //create text node with populate data
		elLink.setAttribute("href", "#"); //do not give any link v give #
		//alert(elLink);
		//alert(t.textContent);
		elLink.appendChild(t);
		li.appendChild(elLink);
		//alert(li);
		ul1.appendChild(li);
	}
}

$(document).on('click', '.attributeOptionLiOnClick', function(event){//upon clicking of second colum elements
	
	//var target = event.target || event.srcElement;
	//var id = event.target.id;
	//var type = event.target.type;
	//removeOptions(document.getElementById("MetaIdDD"));
	var rowcount = document.getElementById("tableData").rows.length;
	var td13 = document.createElement("td");
	var columncount = document.getElementById('tableData').rows[0].cells.length;
	columncount = columncount + 1;
	td13.id = "TD"+rowcount + columncount; //td13
	//alert("TD13 id "+td13.id);
	var tr = document.getElementById("TR"+rowcount);
	tr.appendChild(td13);


	$('#td13.id').empty();//td13
	$('#td14.id').empty();//td14
	//this.id gets the var upon onclick event
	//alert("Upon second click"+this.id);
	var listTemp = (this.id).split(":");
	var id = listTemp[0];
	//alert("the id "+id);
	var type = listTemp[1];
	//alert("type"+type);
	
	QUERYSTRING.attributeOption = id;
	
	if(type == "String"){
		/************** Create Input Text Box Start ******************/
			var x = document.createElement("INPUT");
			x.setAttribute("type", "text");
			x.setAttribute("class", "form-control");
			x.setAttribute("id", "testCaseDescription");
			x.setAttribute("placeholder", "Enter TestCase Description..");
		/************** Create Text Box Ends ************************/
		document.getElementById("TD"+rowcount + columncount).appendChild(x);//td13
	}else if(type.includes("Date")){//kind of string contains
		/************** Create Input Date Start	******************/
			var x = document.createElement("INPUT");
			x.setAttribute("type", "date");
			x.setAttribute("id", "Date1");
		/************** Create Input Date Ends	******************/	
		document.getElementById("TD"+rowcount + columncount).appendChild(x);//td13
		if(type == "Date2"){
			/************** Create Input Date Start ******************/
				var x1 = document.createElement("INPUT");
				x1.setAttribute("type", "date");
				x1.setAttribute("id", "Date2");
			/************** Create Input Date Ends	******************/	
			document.getElementById("TD"+rowcount + columncount).appendChild(x1);//td13
		}
	}else{		
		var request = new XMLHttpRequest();
		request.open("POST", "GetAttributeData", true);
		request.setRequestHeader("Content-type", "text/plain");
		request.send(id);
		//alert("Request To MZ: " + id);	
		request.onreadystatechange = function() {
			if (request.readyState === XMLHttpRequest.DONE) {
				if(request.status === 200){
					//alert(request.responseText);
					var item = JSON.parse(request.responseText);
					var columncount = document.getElementById('tableData').rows[0].cells.length;
					var rowcount = document.getElementById("tableData").rows.length;
					
					//alert("RowLength "+rowcount + "Coulmn Length "+columncount);
					var tableid = rowcount.toString()+columncount.toString();
					addDropDown(item.content, type,tableid);
				}
			}
		}
	}
});
QUERYSTRING.DropDownList = [];
function addDropDown(item, type, tableid){
	var column;
	column = "TD"+tableid;
	
	
	/************** Create Drop Down Start ******************/
		select1 = document.createElement("select");
		select1.className = "form-control";
			QUERYSTRING.attributeSubOption = item[0].attribute;
			select1.onchange = function() {DropDownOptionOnClick(tableid)}//event function syntax
			select1.id = "DropDownDD" + tableid ;
			QUERYSTRING.DropDownList.push("DropDownDD" + tableid);


	/************** Create Drop Down End ******************/
	
	
	for (var i = 0; i < item.length; i++) {			
		/************** Create Drop Down Options Start ******************/
			var option1 = document.createElement("option");
			option1.value = item[i].attribute + ":" + item[i].type;
			option1.innerHTML = item[i].attribute;
		/************** Create Drop Down Options End ******************/
		
		select1.options.add(option1);
		
		document.getElementById(column).appendChild(select1);
	}	
}

function DropDownOptionOnClick(tableID){
	var dropdown = document.getElementById("DropDownDD"+tableID);
	var dropdownValue = dropdown.options[dropdown.selectedIndex].value;//passes the drop down selected value
	
	var listTemp = dropdownValue.split(":");
	var id = listTemp[0];
	var type = listTemp[1];
	
	QUERYSTRING.attributeSubOption = id;
	
	if(type == "DropDown"){
		//as dropdown type create fouth column
		var rowcount = document.getElementById("tableData").rows.length;
		var td14 = document.createElement("td");
	    var columncount = document.getElementById('tableData').rows[0].cells.length;
		columncount = columncount + 1;
		td14.id = "TD"+rowcount + columncount; //td14
		var tr = document.getElementById("TR"+rowcount);
		tr.appendChild(td14);
		
		
		var request = new XMLHttpRequest();
		request.open("POST", "GetAttributeData", true);
		request.setRequestHeader("Content-type", "text/plain");
		request.send(id);
		//alert("Request To MZ: " + id);	
		request.onreadystatechange = function() {
			if (request.readyState === XMLHttpRequest.DONE) {
				if(request.status === 200){
					alert(request.responseText);
					var item = JSON.parse(request.responseText);
					var columncount = document.getElementById('tableData').rows[0].cells.length;
					var rowcount = document.getElementById("tableData").rows.length;
					var tableid = rowcount.toString()+columncount.toString();
					addDropDown(item.content, type, tableid);
				}
			}
		}
	}
}

function process(){//Upon clicking submit button
	
	$('#tblSummary').empty();
	
	var result = validate();
	if(result != "True"){
		alert(result);
		return;
	}
	
	//var str = getContent();
	var str = JSON.stringify(QUERYSTRING);
	
	var request = new XMLHttpRequest();
	request.open("POST", "SubmitRunQueryBuilder", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	alert("Request To MZ: " + str);	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert("request.responseText"+request.responseText);
				//alert("Content received"+request.content);
				loadData(request.responseText);
				//location.reload(true);
			}
		}
	}
	var rowcount = document.getElementById("tableData").rows.length;
	var myUL = document.getElementById('myUL'+rowcount);
	myUL.style.display = 'block';//this is display myUl again.kind of reset of page
	
	QUERYSTRING = new Object();
	var rowcount = document.getElementById("tableData").rows.length;
	var columncount = document.getElementById('tableData').rows[0].cells.length;
	//alert("columncount "+columncount);
	var rowID = document.getElementById("TR"+rowcount);
	//[0,3) [ this means it is inclusive and ) means it is exclusive
	for( var i = columncount-1 ; i > 0 ; i-- ){
		//alert("cou "+i);
		rowID.deleteCell(i);
	}
}

function loadData(itemData){
	var outputTable = document.getElementById('outputTable');
	outputTable.style.display = 'block';
		
	$('#tblSummary').empty();
	
	var listData = itemData.split("$");
	var lgth = listData.length;
	var TestCaseCount = lgth - 1;
	
	var tr = document.createElement('tr');
	tr.name = " TEST CASE IDs ";
	var td1 = document.createElement('td');		
	var text1 = document.createTextNode(tr.name);		
	td1.appendChild(text1);		
	tr.appendChild(td1);
	//alert(tr.name);
	document.getElementById('tblSummary').appendChild(tr);
	
	

	for(var j=1;j<lgth;j++){
		var tr = document.createElement('tr');
		tr.name = listData[j];
		var td1 = document.createElement('td');		
		var text1 = document.createTextNode(tr.name);		
		td1.appendChild(text1);		
		tr.appendChild(td1);
		//alert(tr.name);
		document.getElementById('tblSummary').appendChild(tr);
	}
	//"Test Case Count: " + TestCaseCount +
	
	document.getElementById('thTestCaseId').innerHTML =  "Test Case Count: " + TestCaseCount;
}


function validate(){
	var minLength = 10;
	var result = "True";
	//alert("QUERYSTRING.DropDownList.length "+QUERYSTRING.DropDownList.length);
	if (QUERYSTRING.DropDownList.length == 1){
		FirstDropDownid = QUERYSTRING.DropDownList[0];
		//alert("FirstDropDownid "+FirstDropDownid );
	}else{
		FirstDropDownid = QUERYSTRING.DropDownList[0];
		SecondDropDownid = QUERYSTRING.DropDownList[1];
		//alert("FirstDropDownid "+FirstDropDownid );
		//alert("SecondDropDownid "+SecondDropDownid);
	}
		
	if(QUERYSTRING.attribute == null){
		result = "Please Select an Attribute.\n";
	}else if(QUERYSTRING.attributeOption == null){
		result = "Please Select an Attribute Option.\n";
	}else if(QUERYSTRING.attributeOption == "Description"){
		var testDescription = document.getElementById('testCaseDescription').value;
		if(testDescription == "" || testDescription == null){
			result = "Please Enter Description.\n";
		}else{
			QUERYSTRING.data = testDescription;
		}
	}else if(QUERYSTRING.attributeOption == "MetaId"){
		var dropdown = document.getElementById(FirstDropDownid);
		var dropdownValue = dropdown.options[dropdown.selectedIndex].innerHTML;//passes the drop down selected value
		QUERYSTRING.data = dropdownValue;
	}else if(QUERYSTRING.attributeOption == "Run ID Status"){
		var testDescription = document.getElementById('testCaseDescription').value;
		if(testDescription == "" || testDescription == null){
			result = "Please Enter Description.\n";
		}else{
			QUERYSTRING.data = testDescription;
		}

        }else if(QUERYSTRING.attributeOption == "After" || QUERYSTRING.attributeOption == "Before"){
		var Date1 = document.getElementById('Date1');
		if(Date1.value == ""){
			result = "Please Select a Date Value.\n";
		}else{
			QUERYSTRING.data = Date1.value;
		}
	}else if(QUERYSTRING.attributeOption == "In Between"){
		var Date1 = document.getElementById('Date1');
		var Date2 = document.getElementById('Date2');
		if(Date1.value == "" || Date2.value == ""){
			result = "Please Select a both Date Value.\n";
		}else{
			QUERYSTRING.data = Date1.value + "&" + Date2.value;
		}
	}else if(QUERYSTRING.attributeOption == "CIC Request"){
		var dropdown = document.getElementById(FirstDropDownid);
		var dropdownValue = dropdown.options[dropdown.selectedIndex].innerHTML;
		//alert("dropdownValue of first drop down "+dropdownValue);
		if(dropdownValue == "CIC_REFILL_V001"){
			var dropdown1 = document.getElementById(SecondDropDownid);
			var dropdownValue1 = dropdown1.options[dropdown1.selectedIndex].innerHTML;
			//alert("dropdownValue "+dropdownValue);
			QUERYSTRING.attributeSubOption = dropdownValue;
			//alert("dropdownValue1 "+dropdownValue1);
			QUERYSTRING.data = dropdownValue1;
		}else{
			QUERYSTRING.data = dropdownValue;
		}
	}else if(QUERYSTRING.attributeOption == "Mapping Table Row Insert"){
		var dropdown = document.getElementById(FirstDropDownid);
		var dropdownValue = dropdown.options[dropdown.selectedIndex].innerHTML;
		if(dropdownValue == "MT_GLOBAL_ATTRIBUTES_V2.0"){
			var dropdown1 = document.getElementById(SecondDropDownid);
			var dropdownValue1 = dropdown1.options[dropdown1.selectedIndex].innerHTML;
			QUERYSTRING.attributeSubOption = dropdownValue;
			QUERYSTRING.data = dropdownValue1;
		}else{
			QUERYSTRING.data = dropdownValue;
		}
	}else if(QUERYSTRING.attributeOption == "Mapping Table Row Delete"){
		var dropdown = document.getElementById(FirstDropDownid);
		var dropdownValue = dropdown.options[dropdown.selectedIndex].innerHTML;
		QUERYSTRING.data = dropdownValue;
	}else if(QUERYSTRING.attributeOption == "Contract Type"){
		var dropdown = document.getElementById(FirstDropDownid);
		var dropdownValue = dropdown.options[dropdown.selectedIndex].innerHTML;
		QUERYSTRING.data = dropdownValue;
	}else if(QUERYSTRING.attributeOption == "Service Provided"){
		var dropdown = document.getElementById(FirstDropDownid);
		var dropdownValue = dropdown.options[dropdown.selectedIndex].innerHTML;
		QUERYSTRING.data = dropdownValue;
	}
	return result;
}

function ResetPage(){//function to reset page
	location.reload(true);
}

$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});

