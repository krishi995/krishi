function createXmlHttp() {
	var xhr;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xhr=new XMLHttpRequest();
	} else {// code for IE6, IE5
		xhr=new ActiveXObject('Microsoft.XMLHTTP');
	}
	return xhr;
}

function loadDuplicateTestRunPage() {
	//alert("yo");
	var xhr = createXmlHttp();
	
	xhr.open('GET', 'dupTestRun.html?', true);
	xhr.send();
	
	xhr.onreadystatechange=function() {
		if (xhr.readyState==4 && xhr.status==200) {
			var testScenario = JSON.parse(xhr.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			//alert("hi");
			addRunId(mainPanel, testScenario.content);
		}
	}
	
}

function addRunId(panel, item){
	//alert(item[0].runid)
	for (var i = 0; i < item.length; i++) {
		opt = document.createElement("option");
		opt.text = item[i].runid + " : " + item[i].description;
		document.getElementById('DupRunId').appendChild(opt);
	
		var li = document.createElement("LI");
		li.id = opt.text;
		li.className = 'liOnClick';
		//li.onclick = onchange= function() {report1(li.id)};
		var elLink = document.createElement("A");
		var t = document.createTextNode(opt.text);
		elLink.setAttribute("href", "#");
		elLink.appendChild(t);
		li.appendChild(elLink);
		document.getElementById("myUL").appendChild(li);
		
	}
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
}

$(document).on('click', '.liOnClick', function(){
	document.getElementById("myInput").value = this.id;
	document.getElementById("DupRunId").value = this.id;
	//duplicateTestRun(this.id);
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
});

function duplicateTestRun(){
	
	var result = validate();
	if(result != "True"){
		alert(result);
		return;
	}
	
	var content = getName();
	
	var request = new XMLHttpRequest();
	request.open("POST", "DupRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(content);
	//alert("Test Cases Run Send to MZ." + testCases);
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);
				
				var labelBody = document.getElementById('DuplicateRunId');
				labelBody.innerHTML = request.responseText;				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
}

function getName(){
	var result="";
	var dropdown = document.getElementById("baseLine");
	var dropdownValue = dropdown.options[dropdown.selectedIndex].text;
		
	var txtBox = document.getElementById("testDescription").value;
	
	var DupRunIdDL = document.getElementById("DupRunId");
	var DupRunId = DupRunIdDL.options[DupRunIdDL.selectedIndex].text;
	
	result = dropdownValue + ":" + txtBox + ":" + DupRunId;
	return result;
}

function validate(){
	//alert("Inside validate");
	var result = "True";
	
	var dropdown = document.getElementById("baseLine");
	var dropdownValue = dropdown.options[dropdown.selectedIndex].text;
	//alert(dropdownValue);
	if( dropdownValue == "--Select--"){
		result = "Please select an Environment to Run.\n";
	}
		
	var minLength = 10;
	var txtBox = document.getElementById("testDescription").value;
	if(txtBox.length < minLength ){
		if(result == "True")
			result = "";
		result = result + "Incorect text length. Minimum 10 letters.\n";
	}
	
	var result;
	var baseLineDL = document.getElementById("DupRunId");
	var blText = baseLineDL.options[baseLineDL.selectedIndex].text;
	if (blText == "--Select--") {
		result = result + "Please select an option! From Run Id List.\n";
	}
	//alert("result");
	return result;
}


function myFunction() {
	var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("LI");
	//alert("Hi:" + li[5].getElementsByTagName("a")[0]);
	ul.style.display = 'block';
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("A")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = '';
        } else {
            li[i].style.display = 'none';

        }
    }
}


$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});