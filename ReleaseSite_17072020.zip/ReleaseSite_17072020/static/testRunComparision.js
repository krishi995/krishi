function createXmlHttp() {
	var xhr;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xhr=new XMLHttpRequest();
	} else {// code for IE6, IE5
		xhr=new ActiveXObject('Microsoft.XMLHTTP');
	}
	return xhr;
}

function loadTestRunCompPage() {
	//alert("yo");
	var xhr = createXmlHttp();
	
	xhr.open('GET', 'testRunComp.html?', true);
	xhr.send();
	
	xhr.onreadystatechange=function() {
		if (xhr.readyState==4 && xhr.status==200) {
			var testScenario = JSON.parse(xhr.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			//alert("hi");
			addRunId(mainPanel, testScenario.content);
		}
	}
	
}

function addRunId(panel, item){
	//alert(item);
	for (var i = 0; i < item.length; i++) {
		opt = document.createElement("option");
		opt.text = item[i].runid + " : " + item[i].description;
		
		document.getElementById('baseLine').appendChild(opt);
	
		var li = document.createElement("LI");
		li.id = opt.text;
		li.className = 'liOnClick1';
		//li.onclick = onchange= function() {report1(li.id)};
		var elLink = document.createElement("A");
		var t = document.createTextNode(opt.text);
		elLink.setAttribute("href", "#");
		elLink.appendChild(t);
		li.appendChild(elLink);
		document.getElementById("myUL1").appendChild(li);
		
	}
	var myUL1 = document.getElementById('myUL1');
	myUL1.style.display = 'none';
	
	for (var i = 0; i < item.length; i++) {
		opt = document.createElement("option");
		opt.text = item[i].runid + " : " + item[i].description;
		
		document.getElementById('runCompair').appendChild(opt);
	
		var li = document.createElement("LI");
		li.id = opt.text;
		li.className = 'liOnClick2';
		//li.onclick = onchange= function() {report1(li.id)};
		var elLink = document.createElement("A");
		var t = document.createTextNode(opt.text);
		elLink.setAttribute("href", "#");
		elLink.appendChild(t);
		li.appendChild(elLink);
		document.getElementById("myUL2").appendChild(li);
		
	}
	var myUL2 = document.getElementById('myUL2');
	myUL2.style.display = 'none';
}

$(document).on('click', '.liOnClick1', function(){
	document.getElementById("myInput1").value = this.id;
	document.getElementById("baseLine").value = this.id;
	var myUL1 = document.getElementById('myUL1');
	myUL1.style.display = 'none';
});

$(document).on('click', '.liOnClick2', function(){
	document.getElementById("myInput2").value = this.id;
	document.getElementById("runCompair").value = this.id;
	var myUL1 = document.getElementById('myUL2');
	myUL1.style.display = 'none';
});

function processTestRunCompair(){
	var result = Validate();
	
	if(result != null){	
		var request = new XMLHttpRequest();
		request.open("POST", "RunComparision", true);
		request.setRequestHeader("Content-type", "text/plain");
		request.send(result);
		//alert("Test Cases Run Send to MZ." + testCases);
		alert("Run Ids Send to MZ for Comparision.");
		
		request.onreadystatechange = function() {
			if (request.readyState === XMLHttpRequest.DONE) {
				if(request.status === 200){
					alert(request.responseText);
					
					var labelBody = document.getElementById('status');
					labelBody.innerHTML = request.responseText;				
				}
				else
					alert("Error response:" + request.responseText);
			}
		}
	}
}

function Validate() {
	var result;
	var baseLineDL = document.getElementById("baseLine");
	var blText = baseLineDL.options[baseLineDL.selectedIndex].text;
	if (blText == "--Select--") {
		alert("Please select an option! From Base Line List");
		return null;
	}
	
	var runCompDL = document.getElementById("runCompair");
	var rcText = runCompDL.options[runCompDL.selectedIndex].text;
	if (rcText == "--Select--") {
		alert("Please select an option! From Base Line List");
		return null;
	}
	
	if(blText == rcText){
		alert("Base Line Drop Down List and Run Comparision Drop List option cannot be same.");
		return null;
	}
	
	result = blText + ":" + rcText;
	return result;
}


function myFunction1() {
	var input, filter, ul, li, a, i;
    input = document.getElementById("myInput1");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL1");
    li = ul.getElementsByTagName("LI");
	//alert("Hi:" + li[5].getElementsByTagName("a")[0]);
	ul.style.display = 'block';
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("A")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = '';
        } else {
            li[i].style.display = 'none';

        }
    }
}


function myFunction2() {
	var input, filter, ul, li, a, i;
    input = document.getElementById("myInput2");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL2");
    li = ul.getElementsByTagName("LI");
	//alert("Hi:" + li[5].getElementsByTagName("a")[0]);
	ul.style.display = 'block';
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("A")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = '';
        } else {
            li[i].style.display = 'none';

        }
    }
}


$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});