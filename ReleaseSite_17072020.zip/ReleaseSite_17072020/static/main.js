$(document).ready(function() {
    //set initial state.
    $('#label1').val(this.checked);

    $('#checks').change(function() {
        if(this.checked) {
            var returnVal = confirm("Are you sure?");
            $(this).prop("checked", returnVal);
        }
        $('#label1').val(this.checked);        
    });
});