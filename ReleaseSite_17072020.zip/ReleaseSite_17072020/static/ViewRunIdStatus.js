function createXmlHttp() {
	var xhr;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xhr=new XMLHttpRequest();
	} else {// code for IE6, IE5
		xhr=new ActiveXObject('Microsoft.XMLHTTP');
	}
	return xhr;
}
var RUNID, TESTCASEID, VALUE, STATE, TESTCASESTATUS;
var ErrorRe = [];

function loadViewRunIdPage() {
	//alert("yo");
	
	var stop = document.getElementById('stop');
	stop.style.display = 'none';
	
	var Resume = document.getElementById('Resume');
	Resume.style.display = 'none';
	
	var xhr = createXmlHttp();
	xhr.open('GET', 'loadViewRunIdPage.html?', true);
	xhr.send();
	
	xhr.onreadystatechange=function() {
		if (xhr.readyState==4 && xhr.status==200) {
			var testScenario = JSON.parse(xhr.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			//alert("hi");
			addRunId(mainPanel, testScenario.content);
		}
	}
	
}

function addRunId(panel, item){
	//alert(item);
	for (var i = 0; i < item.length; i++) {
		opt = document.createElement("option");
		opt.id = item[i].runid;
		opt.text = item[i].runid + ": " + item[i].description + " : " + item[i].status1 + " : " + item[i].environment;
		document.getElementById('baseLine').appendChild(opt);
		
		var li = document.createElement("LI");
		li.id = opt.text;
		li.className = 'liOnClick';
		//li.onclick = onchange= function() {report1(li.id)};
		var elLink = document.createElement("A");
		var t = document.createTextNode(opt.text);
		elLink.setAttribute("href", "#");
		elLink.appendChild(t);
		li.appendChild(elLink);
		document.getElementById("myUL").appendChild(li);
		
	}
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
}

$(document).on('click', '.liOnClick', function(){
	document.getElementById("myInput").value = this.id;
	document.getElementById("baseLine").value = this.id;
	report(this.id);
});

function report(value){
	
	document.getElementById("myInput").value = value;
	VALUE = value;
	var stop = document.getElementById('stop');
	stop.style.display = 'none';
	
	var Resume = document.getElementById('Resume');
	Resume.style.display = 'none';
	
	var rerun = document.getElementById('ErrorReRun');
	rerun.style.display = 'none';
		
	var FCEExport = document.getElementById('FCEExport');
	FCEExport.style.display = 'none';
	
	var list = value.split(":")
	var id = list[0];
	//alert(STATE);
	$('#tbody').empty();
	
    var Parent = document.getElementById('tbody');
	while(Parent.hasChildNodes())
	{
	   Parent.removeChild(Parent.firstChild);
	}
	
	RUNID=id;
	STATE=list[2];
	/*
	var xhr = createXmlHttp();
	xhr.open('GET', 'RunId='+id, true);
	xhr.send();
	*/
	var request = new XMLHttpRequest();
	request.open("POST", 'RunId='+id, true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send();
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Run Send to MZ: " + id);
	
	request.onreadystatechange = function() {
		if (request.readyState==4 && request.status==200) {
			//alert("Got Response");
			var testScenario = JSON.parse(request.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			//alert("hi");			
			loadRunData(testScenario.content);
		}
	}
}

function loadRunData(itemData){
	//alert("report" + itemData[0].runIdTestCase);
	$('#tbody').empty();
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
	
	var countFinished = 0, countRun = 0, countError = 0, countReRun = 0, countNS = 0, countRe=0, countFinishedFCE=0, countDropped=0, countAcceptFCE=0;
	var countExec=0, countFCEPassed=0, countFCEFailed=0;
	
	var tabData = itemData[0].runIdTestCase;
	var lgth = tabData.length;
	for(var j=0;j<lgth;j++){
		var tr = document.createElement('tr');
		tr.value = tabData[j].testcaseid;
		tr.name = tabData[j].status;
		//tr.name = tabData[j].testStep;
		tr.style.border = '1px solid black';
		
		var td1 = document.createElement('td');
		var td2 = document.createElement('td');
		var td3 = document.createElement('td');
		
		var text1 = document.createTextNode(tabData[j].testcaseid);
		var text2 = document.createTextNode(tabData[j].description);
		var text3 = document.createTextNode(tabData[j].status);
		
		tr.className = 'rowOnClick';
					
		td1.appendChild(text1);
		td2.appendChild(text2);
		td3.appendChild(text3);
				
		tr.appendChild(td1);
		tr.appendChild(td2);
		tr.appendChild(td3);
		
		//countFinished = 0, countRun = 0, countError = 0, countReRun = 0, countNS = 0;
		if(tabData[j].status == 'Finished'){
			countFinished = countFinished + 1;
			if(countFinished == 1)
				tr.id = 'Finished';
		}else if(tabData[j].status == 'Error'){
			countError = countError + 1;
			if(countError == 1)
				tr.id = 'Error';
		}else if(tabData[j].status == 'Running'){
			countRun = countRun + 1;
			if(countRun == 1)
				tr.id = 'Running';
		}else if(tabData[j].status == 'Error-ReRun'){
			countReRun = countReRun + 1;
			ErrorRe.push(tr.value);
			if(countReRun == 1)
				tr.id = 'Error-ReRun';
		}else if(tabData[j].status == 'Not Started'){
			countNS = countNS + 1;
			if(countNS == 1)
				tr.id = 'Not Started';
		}else if(tabData[j].status == 'ReRun'){
			countRe = countRe + 1;
			if(countRe == 1)
				tr.id = 'ReRun';
		}else if(tabData[j].status == 'Finished-FCE'){
			countFinishedFCE = countFinishedFCE + 1;
			if(countFinishedFCE == 1){
				//alert(tr.value);
				tr.id = 'Finished-FCE';
			}
		}else if(tabData[j].status == 'Dropped'){
			countDropped = countDropped + 1;
			ErrorRe.push(tr.value);
			if(countDropped == 1)
				tr.id = 'Dropped';
		}else if(tabData[j].status == 'FCE Accept'){
			countAcceptFCE = countAcceptFCE + 1;
			if(countAcceptFCE == 1)
				tr.id = 'FCE Accept';
		}else if(tabData[j].status == 'Exception'){
			countExec = countExec + 1;
			if(countExec == 1)
				tr.id = 'Exception';
		}else if(tabData[j].status == 'FCE-Passed'){
			countFCEPassed = countFCEPassed + 1;
			if(countFCEPassed == 1)
				tr.id = 'FCE-Passed';
		}else if(tabData[j].status == 'FCE-Failed'){
			countFCEFailed = countFCEFailed + 1;
			if(countFCEFailed == 1)
				tr.id = 'FCE-Failed';
		}
		
		document.getElementById('tbody').appendChild(tr);
	}
	
	//alert(STATE);
	if(STATE.includes("Running")){
		var stop = document.getElementById('stop');
		stop.style.display = 'block';
	}else if (STATE.includes("Stop")){
		var Resume = document.getElementById('Resume');
		Resume.style.display = 'block';
	}
	
	if((countReRun > 0 || countDropped > 0) && !STATE.includes("Running")){
		var rerun = document.getElementById('ErrorReRun');
		rerun.style.display = 'block';
	}
	
	var arrayName = [];
	var arrayValue = [];
	//countFinished = 0, countRun = 0, countError = 0, countReRun = 0, countNS = 0;
	if(countFinished > 0){
		arrayName.push("Finished");
		arrayValue.push(countFinished);
	}
	if(countFCEPassed > 0){
		arrayName.push("FCE-Passed");
		arrayValue.push(countFCEPassed);
	}
	if(countAcceptFCE > 0){
		arrayName.push("FCE Accept");
		arrayValue.push(countAcceptFCE);
	}
	if(countRun > 0){
		arrayName.push("Running");
		arrayValue.push(countRun);
	}
	if(countRe > 0){
		arrayName.push("ReRun");
		arrayValue.push(countRe);
	}
	if(countError > 0){
		arrayName.push("Error");
		arrayValue.push(countError);
	}
	if(countFCEFailed > 0){
		arrayName.push("FCE-Failed");
		arrayValue.push(countFCEFailed);
	}
	if(countReRun > 0){
		arrayName.push("Error-ReRun");
		arrayValue.push(countReRun);
	}
	if(countExec > 0){
		arrayName.push("Exception");
		arrayValue.push(countExec);
	}
	if(countDropped > 0){
		arrayName.push("Dropped");
		arrayValue.push(countDropped);
	}
	if(countFinishedFCE > 0){
		arrayName.push("Finished-FCE");
		arrayValue.push(countFinishedFCE);
		var FCEExport = document.getElementById('FCEExport');
		FCEExport.style.display = 'block';
	}
	if(countNS > 0){
		arrayName.push("Not Started");
		arrayValue.push(countNS);
	}
	drawBarChart(arrayName,arrayValue,1);
}


function Stop(){
	var request = new XMLHttpRequest();
	request.open("POST", 'StopRunId', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(RUNID);	
	alert("Stop Run Id: " + RUNID);
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if (request.readyState==4 && request.status==200) {
				alert(request.responseText);
				location.reload(true);
			}
		}
	}
}

function Resume(){
	var request = new XMLHttpRequest();
	request.open("POST", 'ResumeRunId', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(RUNID);
	alert("Resume Run Id: " + RUNID);
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if (request.readyState==4 && request.status==200) {
				alert(request.responseText);
				location.reload(true);
			}
		}
	}
}

function ErrorReRun(){
	var str = RUNID + ":" + ErrorRe[0];
	for(var i=1; i<ErrorRe.length; i++){
		str = str + ";" + ErrorRe[i];
	}
	//alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "ReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				location.reload(true);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
}

$(document).on('click', '.rowOnClick', function(){
    var Parent = document.getElementById('tbody1');
	while(Parent.hasChildNodes())
	{
	   Parent.removeChild(Parent.firstChild);
	}
	//alert(this.name);
	var testcaseid = this.value;
	var request = new XMLHttpRequest();
	var str = RUNID + ':' + testcaseid;
	TESTCASEID = testcaseid;
	TESTCASESTATUS = this.name;
	//alert(str);
	request.open("POST", 'RunTestCaseData', true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Test Cases Run Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState==4 && request.status==200) {
			//alert("Got Response");
			var testScenario = JSON.parse(request.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			//alert("hi");			
			loadTestSteps(testScenario.content);
		}
	}
});

function loadTestSteps(tabData){
    var Parent = document.getElementById('tbody1');
	while(Parent.hasChildNodes())
	{
	   Parent.removeChild(Parent.firstChild);
	}
	var testcaseid = this.value;
	var lgth = tabData.length;
	for(var j=0;j<lgth;j++){
		var tr = document.createElement('tr');
		tr.id = tabData[j].stepId;
		tr.style.border = '1px solid black';
		tr.name = tabData[j].errorDiscription;
		
		var td1 = document.createElement('td');
		var td2 = document.createElement('td');
		var td3 = document.createElement('td');
		var td4 = document.createElement('td');
		var td5 = document.createElement('td');
		
		var text1 = document.createTextNode(tabData[j].stepId);
		var text2 = document.createTextNode(tabData[j].userId);
		var text3 = document.createTextNode(tabData[j].description);
		var text4 = document.createTextNode(tabData[j].status);
		
		var requestDesc = tabData[j].description;
		if(!TESTCASESTATUS.includes("Not Started") && !TESTCASESTATUS.includes("Running")){
			if(requestDesc.includes("DATA_VOL") ||requestDesc.includes("BNG_LTE") ||requestDesc.includes("CIC_CLEANUP") ||requestDesc.includes("VVM_VAS") ||
				requestDesc.includes("CUSTOMTHRESHOLD") ||requestDesc.includes("ALW_REPLICATE") ||requestDesc.includes("ACTSUSP") ||
				requestDesc.includes("BALENQUIRY") ||requestDesc.includes("ISG_WIFI") ||requestDesc.includes("OSR_DEBIT") ||
				requestDesc.includes("CIC_BLOCK_ALLOWANCE") ||requestDesc.includes("CIC_REFILL_V001") ||requestDesc.includes("CIC_STATUS") ||
				requestDesc.includes("POLICY_REQ") ||requestDesc.includes("CIC_REFILL_BIT") ||requestDesc.includes("ZRIL_MAV_SMS") ||
				requestDesc.includes("GPAS_VALIDITY_EXTEND") ||requestDesc.includes("CHECK_TIBCO_NOTIF") ||requestDesc.includes("OCC") ||
				requestDesc.includes("RECHARGE_REVERSAL") ||requestDesc.includes("BTM_BTN_BTT_V1.0") ||requestDesc.includes("CIC_ACTIVATION") ||
				requestDesc.includes("ZRIL_MAV_IMS") ||requestDesc.includes("CIC_CREDIT_ADJUSTMENT") ||requestDesc.includes("CIC_QUEUE2STACK") ||
				requestDesc.includes("startUsageSession") || requestDesc.includes("updateUsageSession") || requestDesc.includes("stopUsageSession") ||
				requestDesc.includes("NON-MONETARY-BALANCE_TRANSFERV1.0")){
					
				var btn = document.createElement("BUTTON");        		// Create a <button> element
				var t = document.createTextNode("Request");				// Create a text node
				btn.appendChild(t);                              		// Append the text to <button>
				btn.className = 'btnOnClickReq';
				btn.name = RUNID + ":" + TESTCASEID + ":" + tabData[j].stepId;
				td5.appendChild(btn);
			}
		}
		if(tabData[j].status == "Finished-FCE"){
			var hr = document.createElement("P");
			td5.appendChild(hr);
						
			var btn = document.createElement("BUTTON");        		// Create a <button> element
			var t = document.createTextNode("Accept");				// Create a text node
			btn.appendChild(t);                              		// Append the text to <button>
			btn.className = 'btnOnClickAccept';
			btn.name = TESTCASEID + ":" + tabData[j].stepId;
			//td5.appendChild(btn);
		}
		
		if(tabData[j].status == "FCE Expected"){
			var hr = document.createElement("P");
			td5.appendChild(hr);
						
			var btn = document.createElement("BUTTON");        		// Create a <button> element
			var t = document.createTextNode("Enter Message");				// Create a text node
			btn.appendChild(t);                              		// Append the text to <button>
			btn.className = 'btnOnClickMSG';
			btn.name = TESTCASEID + ":" + tabData[j].stepId;
			//td5.appendChild(btn);
		}
			
		td1.appendChild(text1);
		td2.appendChild(text2);
		td3.appendChild(text3);
		td4.appendChild(text4);
		
		tr.appendChild(td1);
		tr.appendChild(td2);
		tr.appendChild(td3);
		tr.appendChild(td4);
		tr.appendChild(td5);
		
		if(tabData[j].status == "Error-ReRun" || tabData[j].status == "Error" || tabData[j].status == "Finished-FCE" || tabData[j].status == "Exception"
			|| tabData[j].status == "FCE Expected" || tabData[j].status == "FCE-Passed" || tabData[j].status == "FCE-Failed"){
			var hr = document.createElement("P");
			td5.appendChild(hr);
			
			var btn = document.createElement("BUTTON");        		// Create a <button> element
			var t = document.createTextNode("View Error");				// Create a text node
			btn.appendChild(t);                              		// Append the text to <button>
			btn.className = 'btnOnClickError';
			btn.name = tabData[j].errorDiscription;
			td5.appendChild(btn);
			//tr.className = 'rowOnClick1';
		}
		document.getElementById('tbody1').appendChild(tr);
	}
	document.getElementById('TestCaseId').innerHTML = "TestCaseId= " + TESTCASEID;
		    
	$('#myModal').modal({show:true});
}

$(document).on('click', '.btnOnClickError', function(){
	alert(this.name);
});

$(document).on('click', '.rowOnClick1', function(){
	alert(this.name);
});

$(document).on('click','.btnOnClickAccept', function(){
	var checkFlag = confirm("You want to Accept FCE of testCaseId:stepId = " + this.name);
	if(checkFlag == false){
		alert("Not Accepted");
		return;
	}
	
	
	var request = new XMLHttpRequest();
	request.open("POST", "AcceptFCE", true);
	request.setRequestHeader("Content-type", "text/plain");
	//alert(str);
	request.send(this.name);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);
			}
		}
	}
});

$(document).on('click','.btnOnClickMSG', function(){
	//var checkFlag = confirm("You want to Accept FCE of testCaseId:stepId = " + this.name);
	var Message = prompt("Enter Error Message!", "Text");
	//alert(Message);
	if(Message == null || Message == 'Text' || Message == ''){
		return;
	}
		
	/*if(checkFlag == false){
		alert("Not Accepted");
		return;
	}*/
	//alert(Message);
	var content = this.name + "@" + Message;
	var request = new XMLHttpRequest();
	request.open("POST", "FCEMessage", true);
	request.setRequestHeader("Content-type", "text/plain");
	//alert(str);
	request.send(content);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);
			}
		}
	}
});

$(document).on('click','.btnOnClickReq', function(){
	//alert(this.name);
	var request = new XMLHttpRequest();
	request.open("POST", "Request", true);
	request.setRequestHeader("Content-type", "text/plain");
	//alert(str);
	request.send(this.name);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				//class="form-control" rows="20"
				var randomnumber = Math.floor((Math.random()*100)+1); 
				
				var myWindow = window.open("", "msgWindow", "width=600,height=600");
				var newContent = myWindow.document.createElement("textarea");
				newContent.value = request.responseText;
				newContent.class = "form-control";
				newContent.rows = "37";
				newContent.style.width = "550px";
				myWindow.document.body.appendChild(newContent);
				//myWindow.close();
				//myWindow.document.write(request.responseText);
			}
		}
	}
});

$(document).on('click', '.btnOnClick1', function(){
	
	var request = new XMLHttpRequest();
	request.open("POST", "ReRun", true);
	request.setRequestHeader("Content-type", "text/plain");
	var str = RUNID + ":" + this.name;
	//alert(str);
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);

				location.reload(true);				
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
});

$(document).on('hidden.bs.modal', function (e) {
	//alert("Hi1");
    var Parent = document.getElementById('tbody1');
	while(Parent.hasChildNodes())
	{
	   Parent.removeChild(Parent.firstChild);
	}
});

setInterval(function(){
	if(STATE.includes("Running")){
		report(VALUE);
	}
}, 60000);


function myFunction() {
	var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("LI");
	//alert("Hi:" + li[5].getElementsByTagName("a")[0]);
	ul.style.display = 'block';
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("A")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = '';
        } else {
            li[i].style.display = 'none';

        }
    }
}



$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});


function FCEExport(){
	var str = RUNID;
	//alert(str);
	
	var request = new XMLHttpRequest();
	request.open("POST", "FCEExport", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	//alert("Test Cases Run Send to MZ." + testCases);
	//alert("Request Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				//alert(request.responseText);
				var data = JSON.parse(request.responseText);
				//alert(data);
				exportFCEReport(data);			
			}
			else
				alert("Error response:" + request.responseText);
		}
	}
}

function exportFCEReport(output){
	//alert("hi");
	var data = output.reportFCE
	var lgth = data.length;
	//alert(data[0].testCaseId);
	const rows = new Array();
	for(var j=0; j<lgth; j++){
		rows[j] = new Array(data[j].testCaseId, data[j].stepId, data[j].operName, data[j].name, data[j].errorDesc, data[j].testCaseDesc, data[j].fileName);
	}
	//alert(rows);
	let csvContent = "data:text/csv;charset=utf-8,";
	rows.forEach(function(rowArray){
	   let row = rowArray.join(",");
	   csvContent += row + "\r\n";
	});
	//alert(csvContent);
	var encodedUri = encodeURI(csvContent);
	//window.open(encodedUri);
	var link = document.createElement("a");
	link.setAttribute("href", encodedUri);
	link.setAttribute("download", "reportFCE_" + RUNID + ".csv");
	link.innerHTML= "Click Here to download";
	document.body.appendChild(link); // Required for FF

	link.click();
}


$(document).on('click', '.rectOnClick1', function(){
	//alert(this.id);
	//alert(this.name);
	//alert(this.value);
	//var elmnt = document.getElementById(this.id);
	
	var tag = document.getElementsByTagName('tr');
	//alert(tag.length);
	for(var i=0; i<tag.length; i++){
		if(tag[i].name == this.id){
			//alert("We almost Got This: " + tag[i].id);
			//alert(tag[i].value);
			tag[i-1].scrollIntoView();
			break;
		}
	}
	//alert(tag[i].id);
    //elmnt.scrollIntoView();	
});

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 170;
    document.documentElement.scrollTop = 170;
}