function createXmlHttp() {
	var xhr;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xhr=new XMLHttpRequest();
	} else {// code for IE6, IE5
		xhr=new ActiveXObject('Microsoft.XMLHTTP');
	}
	return xhr;
}

function loadTestRunPage() {
	var xhr = createXmlHttp();
	xhr.onreadystatechange=function() {
		if (xhr.readyState==4 && xhr.status==200) {
			var testScenario = JSON.parse(xhr.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			for(i=0;i<testScenarioLen;++i) {
				addTestScenarioRow(mainPanel, testScenario.content[i]);
			}
		}
	}
	
	xhr.open('GET', 'scenario_load.html?', true);
	xhr.send();
}

function addTestScenarioRow(panel, item) {
	var rowDiv = document.createElement('div');
	panel.appendChild(rowDiv);
	rowDiv.className = 'panel panel-default';
	// create heading
	var headingDiv = document.createElement('div');
	rowDiv.appendChild(headingDiv);
	headingDiv.className = 'panel-heading';
	
	var headingTitleDiv = document.createElement('h4');
	headingDiv.appendChild(headingTitleDiv);
	headingTitleDiv.className = 'panel-title';
	
	var checkBoxItem = document.createElement('input');
	headingTitleDiv.appendChild(checkBoxItem);
	checkBoxItem.type = 'checkbox';
	checkBoxItem.id = item.title;
	checkBoxItem.className = 'checkOnClick';
	
	var headingToggle = document.createElement('a');
	headingTitleDiv.appendChild(headingToggle);
	headingToggle.setAttribute('data-toggle', 'collapse');
	headingToggle.setAttribute('data-parent', '#accordion');
	headingToggle.setAttribute('href', '#' + item.id);
	var title = "  " + item.title;
	headingToggle.appendChild(document.createTextNode(title));
		
	var itemDiv = document.createElement('div');
	rowDiv.appendChild(itemDiv);
	itemDiv.className = 'panel-collapse collapse';
	itemDiv.id = item.id;
		
	var itemBody = document.createElement('div');
	itemDiv.appendChild(itemBody);
	itemBody.className = 'panel-body';
	itemBody.appendChild(document.createTextNode('Select One or Multiple Test Cases'));
	
	var itemLen = item.item.length;
	var i;
	for(i=0;i<itemLen;++i) {
		var checkBoxDiv = document.createElement('div');
		itemBody.appendChild(checkBoxDiv);
		checkBoxDiv.className = 'checkbox';
				
		var labelBody = document.createElement('label');
		checkBoxDiv.appendChild(labelBody);
		
		var checkBoxBody = document.createElement('input');
		checkBoxDiv.appendChild(checkBoxBody);
		checkBoxBody.type = 'checkbox';
		checkBoxBody.name = item.title + "_check";
		checkBoxBody.id = item.item[i].id;
		checkBoxBody.className = 'check';
		
		checkBoxDiv.appendChild(document.createTextNode(item.item[i].value));
	}
}

$(document).on('click', '.checkOnClick', function(){
	//alert("Inside function checkUncheck" + this.id);
	var name = this.id + "_check";
	var checkBox = document.getElementsByName(name);
	var countChkBox = 0;
	var i;
	//alert("checkBox"+checkBox);
	for (i = 0; i < checkBox.length; i++) {
		//alert(checkBox[i]);
		countChkBox = countChkBox + 1;
		if (this.checked) {
			checkBox[i].checked = true;
		}else{
			checkBox[i].checked = false;
		}
	}
	//alert('Number Of Checkbox' + countChkBox);
});

function processSubmitTestRun(){
	alert("processSubmitTestRun");
	
	var result = validate();
	if(result != "True"){
		alert(result);
		return;
	}

	var testCases = getName();
	
	var checkboxresult = document.getElementById("myCheck");
	var checkBoxData;
	if(checkboxresult.checked == true){
		checkBoxData = "1";
	}else if(checkboxresult.checked == false){
		checkBoxData = "0";
	}
	//alert(testCases);
	var dropdown = document.getElementById("baseLine");
	var dropdownValue = dropdown.options[dropdown.selectedIndex].text;
	//alert("DropdownValue : "+ dropdownValue )
	var request = new XMLHttpRequest();
	request.open("POST", "http://10.137.167.12:8085/TestRun:" + dropdownValue + ":" + checkBoxData, true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(testCases);
	alert("Test Cases Run Send to MZ." + testCases);
	//alert("Test Cases Run Send to MZ.");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);
				
				var labelBody = document.getElementById('runId');
				labelBody.innerHTML = request.responseText;				
			}
			else
				alert("Response:" + request.responseText);
		}
	}
}

function getName(){
	var checkBox = document.getElementsByClassName('check');
	var result = "1&";
	var i;
	var array = [];
	for (i = 0; i < checkBox.length; i++) {
		if (checkBox[i].checked) {
			if(result == ""){
				result = result + checkBox[i].id + "&";
				array.push(checkBox[i].id)
			}else if(array.indexOf(checkBox[i].id) == -1){
				result = result + checkBox[i].id + "&";
				array.push(checkBox[i].id)
			}
		}
	}
	alert(result);
	var txtBox = document.getElementById("testDescription").value;
	result = result + txtBox;
	return result;
}

function validate(){
	alert("Inside validate");
	var result = "True";
	
	var dropdown = document.getElementById("baseLine");
	var dropdownValue = dropdown.options[dropdown.selectedIndex].text;
	alert(dropdownValue);
	if( dropdownValue == "--Select--"){
		result = "Please select an Environment to Run.\n";
	}
	
	var checkBox = document.getElementsByClassName('check');
	var countChkBox = 0;
	var i;
	//alert("checkBox"+checkBox);
	for (i = 0; i < checkBox.length; i++) {
		//alert(checkBox[i]);
		if (checkBox[i].checked) {
			countChkBox = countChkBox + 1;
		}
	}
	
	if(countChkBox == 0){
		if(result = "True")
			result == "";
		result = result + "Atleast one TestCase should be selected.\n";
	}
	
	var minLength = 10;
	var txtBox = document.getElementById("testDescription").value;
	if(txtBox.length < minLength ){
		if(result == "True")
			result = "";
		result = result + "Incorect text length. Minimum 10 letters.\n";
	}
	
	//alert("result");
	return result;
}

function report(id){
	//alert(document.getElementById("baseLine").options[document.getElementById("baseLine").selectedIndex].text);
}

$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
