function createXmlHttp() {
	var xhr;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xhr=new XMLHttpRequest();
	} else {// code for IE6, IE5
		xhr=new ActiveXObject('Microsoft.XMLHTTP');
	}
	return xhr;
}

function loadEditMetaInfoPage() {
	//alert("yo");
	var xhr = createXmlHttp();
	
	xhr.open('GET', 'EditMetaInfo.html?', true);
	xhr.send();
	
	xhr.onreadystatechange=function() {
		if (xhr.readyState==4 && xhr.status==200) {
			var testScenario = JSON.parse(xhr.responseText);
			var testScenarioLen = testScenario.content.length;
			var i;
			var rowPos=0;
			var mainPanel = document.getElementById('accordion');
			//alert("hi");
			addTestCaseId(mainPanel, testScenario.content);
		}
	}
	
}

function addTestCaseId(panel, item){
	//alert(item[0].testcaseid)
	for (var i = 0; i < item.length; i++) {
		opt = document.createElement("option");
		opt.text = item[i].testcaseid + " : " + item[i].description;
		document.getElementById('TestCaseId').appendChild(opt);
	
		var li = document.createElement("LI");
		li.id = item[i].description;
		li.value = item[i].testcaseid;
		li.className = 'liOnClick';
		//li.onclick = onchange= function() {report1(li.id)};
		var elLink = document.createElement("A");
		var t = document.createTextNode(opt.text);
		elLink.setAttribute("href", "#");
		elLink.appendChild(t);
		li.appendChild(elLink);
		document.getElementById("myUL").appendChild(li);
		
	}
	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
}

var TESTCASEID;
$(document).on('click', '.liOnClick', function(){
	document.getElementById("myInput").value = this.value + " : " + this.id;
	document.getElementById("TestCaseId").value = this.value + " : " + this.id;
	document.getElementById("testDescription").value = this.id;
	//alert(this.value);
	TESTCASEID = this.value;

	var myUL = document.getElementById('myUL');
	myUL.style.display = 'none';
});

	
function process(){
	var result = validate();
	if(result != "True"){
		alert(result);
		return;
	}
	
	var queryName = getName();
	//alert(filename3);
	var str = TESTCASEID + "&" + queryName;
	//alert(str);
	
	//alert("csv: " + csv);
	var request = new XMLHttpRequest();
	request.open("POST", "UpdateTestCase", true);
	request.setRequestHeader("Content-type", "text/plain");
	request.send(str);
	alert("Request To Modify Send to MZ");
	
	request.onreadystatechange = function() {
		if (request.readyState === XMLHttpRequest.DONE) {
			if(request.status === 200){
				alert(request.responseText);
				var labelBody = document.getElementById('TestCaseId');
				labelBody.innerHTML = request.responseText;
			}
		}
	}
}

function getName(){
	var checkBox = document.forms['TestCaseForm'];
	var result = "";
	
	var textBox = document.getElementById("testDescription");
	var txt = textBox.value;
	if(txt != ""){
		var temp = txt.replace(/ /g, "_");
		var temp1 = temp.replace(/&/g, "$");
		result = temp1;
	}
	
	var i;
	for (i = 0; i < checkBox.length; i++) {
		if (checkBox[i].checked) {
			result = result + "&" + checkBox[i].value;
		}
	}
	
	//alert(result);
	return result;
}

function validate(){
	//alert("Inside validate");
	var minLength = 40;
	var result = "True";
	var txtBox = document.getElementById("testDescription").value;
	if(txtBox.length < minLength ){
		result = "Incorect text length. Minimum 40 letters.\n";
	}
	
	var checkBox = document.forms['TestCaseForm'];
	var countChkBox = 0;
	var i;
	for (i = 0; i < checkBox.length; i++) {
		if (checkBox[i].checked) {
			countChkBox = countChkBox + 1;
		}
	}
	
	if(countChkBox == 0){
		if(result == "True")
			result = "";
		result = result + "Atleast one checkBox should be checked.";
	}
	return result;
}

function myFunction() {
	var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("LI");
	//alert("Hi:" + li[5].getElementsByTagName("a")[0]);
	ul.style.display = 'block';
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("A")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = '';
        } else {
            li[i].style.display = 'none';

        }
    }
}


$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});